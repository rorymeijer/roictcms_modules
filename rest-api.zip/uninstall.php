<?php
/**
 * REST API Module - Uninstall
 */

defined('ROICT_CMS') or die('No direct access');

$db = Database::getInstance();
$db->query("DROP TABLE IF EXISTS " . DB_PREFIX . "api_keys");

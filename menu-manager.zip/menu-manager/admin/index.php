<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();
$db         = Database::getInstance();
$prefix     = DB_PREFIX;
$pageTitle  = 'Menu Beheer';
$activePage = 'menu-manager';

// ─── Sync CMS-pagina's bij elke paginaopening ────────────────────────────────
if (function_exists('menu_manager_sync_pages')) {
    menu_manager_sync_pages();
}

// ─── Allowed locations ────────────────────────────────────────────────────────
$locations = ['header' => 'Header', 'footer' => 'Footer'];

// ─── Active tab ───────────────────────────────────────────────────────────────
$tab = in_array($_GET['tab'] ?? '', array_keys($locations))
     ? $_GET['tab']
     : 'header';

$msg   = '';
$error = '';

// ─── Handle POST actions ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // Add / Edit
    if (in_array($action, ['add', 'edit'])) {
        $label    = trim($_POST['label'] ?? '');
        $url      = trim($_POST['url'] ?? '');
        $location = in_array($_POST['location'] ?? '', array_keys($locations))
                  ? $_POST['location'] : 'header';
        $target   = ($_POST['target'] ?? '_self') === '_blank' ? '_blank' : '_self';
        $order    = (int) ($_POST['sort_order'] ?? 0);
        $active   = isset($_POST['is_active']) ? 1 : 0;

        if ($label === '' || $url === '') {
            $error = 'Vul zowel het label als de URL in.';
        } else {
            if ($action === 'add') {
                $db->query(
                    "INSERT INTO `{$prefix}menu_items`
                        (label, url, location, sort_order, target, is_active)
                     VALUES (?, ?, ?, ?, ?, ?)",
                    [$label, $url, $location, $order, $target, $active]
                );
                $msg = 'Menu-item toegevoegd.';
            } else {
                $id = (int) ($_POST['id'] ?? 0);
                $db->query(
                    "UPDATE `{$prefix}menu_items`
                     SET label=?, url=?, location=?, sort_order=?, target=?, is_active=?
                     WHERE id=?",
                    [$label, $url, $location, $order, $target, $active, $id]
                );
                $msg = 'Menu-item bijgewerkt.';
            }
            header('Location: ?tab=' . $location . '&saved=1');
            exit;
        }
    }

    // Delete
    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        // Fetch location before delete so we redirect to the right tab
        $row = $db->fetch("SELECT location FROM `{$prefix}menu_items` WHERE id=?", [$id]);
        $db->query("DELETE FROM `{$prefix}menu_items` WHERE id=?", [$id]);
        header('Location: ?tab=' . ($row['location'] ?? 'header') . '&deleted=1');
        exit;
    }

    // Toggle active
    if ($action === 'toggle') {
        $id  = (int) ($_POST['id'] ?? 0);
        $row = $db->fetch("SELECT is_active, location FROM `{$prefix}menu_items` WHERE id=?", [$id]);
        $db->query(
            "UPDATE `{$prefix}menu_items` SET is_active=? WHERE id=?",
            [$row['is_active'] ? 0 : 1, $id]
        );
        header('Location: ?tab=' . ($row['location'] ?? 'header'));
        exit;
    }

    // Reorder (drag-and-drop saves JSON order)
    if ($action === 'reorder') {
        $order = json_decode($_POST['order'] ?? '[]', true);
        if (is_array($order)) {
            foreach ($order as $i => $itemId) {
                $db->query(
                    "UPDATE `{$prefix}menu_items` SET sort_order=? WHERE id=?",
                    [$i, (int) $itemId]
                );
            }
        }
        echo json_encode(['ok' => true]);
        exit;
    }
}

// ─── Flash messages from redirect ────────────────────────────────────────────
if (isset($_GET['saved']))   $msg  = 'Menu-item opgeslagen.';
if (isset($_GET['deleted'])) $msg  = 'Menu-item verwijderd.';

// ─── Load items for active tab ────────────────────────────────────────────────
$items = $db->fetchAll(
    "SELECT * FROM `{$prefix}menu_items` WHERE location = ? ORDER BY sort_order ASC, id ASC",
    [$tab]
) ?: [];

// ─── Item to edit (if ?edit=ID) ───────────────────────────────────────────────
$editItem = null;
if (isset($_GET['edit'])) {
    $editItem = $db->fetch(
        "SELECT * FROM `{$prefix}menu_items` WHERE id=?",
        [(int) $_GET['edit']]
    ) ?: null;
}

require_once ADMIN_PATH . '/includes/header.php';
?>

<style>
.menu-table th { font-size:.78rem; text-transform:uppercase; color:var(--text-muted); font-weight:600; }
.menu-table td { vertical-align:middle; }
.drag-handle { cursor:grab; color:var(--text-muted); }
.drag-handle:active { cursor:grabbing; }
.sortable-ghost { opacity:.35; background:var(--surface); }
.badge-loc { font-size:.7rem; padding:.25em .55em; border-radius:.3rem; }
.form-panel { background:var(--surface,#f8f9fa); border:1.5px solid var(--border,#dee2e6); border-radius:.6rem; padding:1.4rem 1.6rem; }
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 style="font-size:1.4rem;font-weight:800;margin:0;">
        <i class="bi bi-list-ul me-2" style="color:var(--primary);"></i>Menu Beheer
    </h1>
    <a href="<?= BASE_URL ?>/admin/modules/" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Terug naar modules
    </a>
</div>

<?php if ($msg):  ?>
<div class="alert alert-success alert-dismissible fade show py-2" role="alert">
    <i class="bi bi-check-circle me-1"></i><?= htmlspecialchars($msg) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show py-2" role="alert">
    <i class="bi bi-exclamation-triangle me-1"></i><?= htmlspecialchars($error) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- ── Tabs ─────────────────────────────────────────────────────────────────── -->
<div class="mb-4 d-flex gap-2 flex-wrap">
<?php foreach ($locations as $key => $label): $active = $tab === $key; ?>
    <a href="?tab=<?= $key ?>"
       style="display:inline-flex;align-items:center;gap:.4rem;
              padding:.45rem 1.1rem;border-radius:.5rem;text-decoration:none;font-weight:600;font-size:.93rem;
              border:1.5px solid <?= $active ? 'var(--primary)' : 'var(--border,#dee2e6)' ?>;
              background:<?= $active ? 'var(--primary)' : 'white' ?>;
              color:<?= $active ? 'white' : 'var(--text-muted,#6c757d)' ?>;">
        <i class="bi bi-<?= $key === 'header' ? 'layout-text-window-reverse' : 'layout-text-sidebar-reverse' ?>"></i>
        <?= htmlspecialchars($label) ?>
        <?php
            $cnt = $db->fetch("SELECT COUNT(*) c FROM `{$prefix}menu_items` WHERE location=?", [$key])['c'] ?? 0;
            if ($cnt > 0):
        ?>
        <span style="background:<?= $active ? 'rgba(255,255,255,.3)' : 'var(--primary)' ?>;
                     color:<?= $active ? 'white' : 'white' ?>;
                     border-radius:1rem;padding:.1em .55em;font-size:.75rem;"><?= $cnt ?></span>
        <?php endif; ?>
    </a>
<?php endforeach; ?>
</div>

<!-- ── Add / Edit form ────────────────────────────────────────────────────────── -->
<div class="form-panel mb-4">
    <h5 style="font-weight:700;margin-bottom:1rem;">
        <i class="bi bi-<?= $editItem ? 'pencil' : 'plus-circle' ?> me-2" style="color:var(--primary);"></i>
        <?= $editItem ? 'Menu-item bewerken' : 'Nieuw menu-item toevoegen' ?>
    </h5>
    <form method="post" action="?tab=<?= htmlspecialchars($tab) ?>">
        <input type="hidden" name="action" value="<?= $editItem ? 'edit' : 'add' ?>">
        <?php if ($editItem): ?>
        <input type="hidden" name="id" value="<?= (int)$editItem['id'] ?>">
        <?php endif; ?>

        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label fw-semibold" style="font-size:.875rem;">Label</label>
                <input type="text" name="label" class="form-control" required
                       placeholder="bijv. Over ons"
                       value="<?= htmlspecialchars($editItem['label'] ?? '') ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold" style="font-size:.875rem;">URL</label>
                <input type="text" name="url" class="form-control" required
                       placeholder="bijv. /over-ons of https://..."
                       value="<?= htmlspecialchars($editItem['url'] ?? '') ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold" style="font-size:.875rem;">Locatie</label>
                <select name="location" class="form-select">
                    <?php foreach ($locations as $key => $lbl): ?>
                    <option value="<?= $key ?>"
                        <?= ($editItem['location'] ?? $tab) === $key ? 'selected' : '' ?>>
                        <?= htmlspecialchars($lbl) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label fw-semibold" style="font-size:.875rem;">Volgorde</label>
                <input type="number" name="sort_order" class="form-control" min="0"
                       value="<?= (int)($editItem['sort_order'] ?? count($items)) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold" style="font-size:.875rem;">Opties</label>
                <div class="d-flex flex-column gap-1">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="target" value="_blank" id="chkBlank"
                               <?= ($editItem['target'] ?? '_self') === '_blank' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="chkBlank" style="font-size:.85rem;">Nieuw tabblad</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="chkActive"
                               <?= ($editItem['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="chkActive" style="font-size:.85rem;">Actief</label>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex gap-2 mt-3">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="bi bi-<?= $editItem ? 'save' : 'plus-lg' ?> me-1"></i>
                <?= $editItem ? 'Opslaan' : 'Toevoegen' ?>
            </button>
            <?php if ($editItem): ?>
            <a href="?tab=<?= htmlspecialchars($tab) ?>" class="btn btn-outline-secondary btn-sm">Annuleren</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- ── Items list ─────────────────────────────────────────────────────────────── -->
<div class="cms-card" style="padding:0;overflow:hidden;">
    <?php if (empty($items)): ?>
    <div class="text-center py-5" style="color:var(--text-muted);">
        <i class="bi bi-menu-button-wide" style="font-size:2.5rem;"></i>
        <p class="mt-2 mb-0">Nog geen menu-items voor de <?= strtolower($locations[$tab]) ?>.</p>
    </div>
    <?php else: ?>
    <table class="table menu-table mb-0">
        <thead style="background:var(--surface,#f8f9fa);">
            <tr>
                <th style="width:2rem;padding-left:1.1rem;"></th>
                <th>Label</th>
                <th>URL</th>
                <th>Tabblad</th>
                <th>Volgorde</th>
                <th>Status</th>
                <th></th>
            </tr>
        </thead>
        <tbody id="sortable-list">
        <?php foreach ($items as $item): ?>
            <tr data-id="<?= (int)$item['id'] ?>">
                <td style="padding-left:1.1rem;">
                    <i class="bi bi-grip-vertical drag-handle fs-5"></i>
                </td>
                <td>
                    <strong><?= htmlspecialchars($item['label']) ?></strong>
                    <?php if (($item['source'] ?? 'manual') === 'page'): ?>
                    <span class="badge ms-1" style="background:#e8f0fe;color:#1a56db;font-size:.68rem;">pagina</span>
                    <?php endif; ?>
                </td>
                <td style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
                    <a href="<?= htmlspecialchars($item['url']) ?>" target="_blank"
                       style="color:var(--primary);font-size:.875rem;">
                        <?= htmlspecialchars($item['url']) ?>
                        <i class="bi bi-box-arrow-up-right ms-1" style="font-size:.7rem;"></i>
                    </a>
                </td>
                <td>
                    <?php if ($item['target'] === '_blank'): ?>
                    <span class="badge bg-secondary badge-loc">Nieuw tabblad</span>
                    <?php else: ?>
                    <span style="color:var(--text-muted);font-size:.82rem;">Zelfde</span>
                    <?php endif; ?>
                </td>
                <td style="font-size:.875rem;color:var(--text-muted);"><?= (int)$item['sort_order'] ?></td>
                <td>
                    <form method="post" action="?tab=<?= htmlspecialchars($tab) ?>" style="display:inline;">
                        <input type="hidden" name="action" value="toggle">
                        <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
                        <button type="submit" class="btn btn-sm p-0 border-0 bg-transparent"
                                title="<?= $item['is_active'] ? 'Deactiveren' : 'Activeren' ?>">
                            <?php if ($item['is_active']): ?>
                            <span class="badge" style="background:#d4edda;color:#155724;font-size:.72rem;">Actief</span>
                            <?php else: ?>
                            <span class="badge" style="background:#f8d7da;color:#721c24;font-size:.72rem;">Inactief</span>
                            <?php endif; ?>
                        </button>
                    </form>
                </td>
                <td class="text-end pe-3">
                    <div class="d-flex gap-2 justify-content-end">
                        <a href="?tab=<?= htmlspecialchars($tab) ?>&edit=<?= (int)$item['id'] ?>"
                           class="btn btn-outline-primary btn-sm py-0">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <form method="post" action="?tab=<?= htmlspecialchars($tab) ?>"
                              onsubmit="return confirm('Menu-item \'<?= htmlspecialchars(addslashes($item['label'])) ?>\' verwijderen?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$item['id'] ?>">
                            <button type="submit" class="btn btn-outline-danger btn-sm py-0">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p class="text-muted m-0 px-3 py-2" style="font-size:.78rem;">
        <i class="bi bi-info-circle me-1"></i>Sleep rijen om de volgorde aan te passen. Wijzigingen worden automatisch opgeslagen.
    </p>
    <?php endif; ?>
</div>

<!-- ── SortableJS (CDN) ───────────────────────────────────────────────────────── -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.2/Sortable.min.js"></script>
<script>
(function () {
    const list = document.getElementById('sortable-list');
    if (!list) return;

    Sortable.create(list, {
        handle: '.drag-handle',
        animation: 150,
        ghostClass: 'sortable-ghost',
        onEnd: function () {
            const order = [...list.querySelectorAll('tr[data-id]')].map(tr => tr.dataset.id);
            const tab   = new URLSearchParams(location.search).get('tab') || 'header';
            fetch('?tab=' + tab, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=reorder&order=' + encodeURIComponent(JSON.stringify(order))
            });
        }
    });
})();
</script>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

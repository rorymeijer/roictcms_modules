<?php

// ─── Admin sidebar ────────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'menu-manager' ? 'active' : '';
    echo '<a href="' . BASE_URL . '/admin/modules/menu-manager/" class="nav-link ' . $isActive . '">'
       . '<i class="bi bi-list-ul"></i> Menu Beheer</a>';
});

// ─── Helper: fetch active items for a location ────────────────────────────────
if (!function_exists('get_menu_items')) {
    function get_menu_items(string $location): array
    {
        $db     = Database::getInstance();
        $prefix = DB_PREFIX;

        return $db->fetchAll(
            "SELECT * FROM `{$prefix}menu_items`
             WHERE location = ? AND is_active = 1
             ORDER BY sort_order ASC, id ASC",
            [$location]
        ) ?: [];
    }
}

// ─── Filter hooks so themes can pull managed items ────────────────────────────
add_filter('header_nav_items', function (array $items): array {
    foreach (get_menu_items('header') as $row) {
        $items[] = [
            'label'  => $row['label'],
            'url'    => $row['url'],
            'target' => $row['target'],
        ];
    }
    return $items;
});

add_filter('footer_nav_items', function (array $items): array {
    foreach (get_menu_items('footer') as $row) {
        $items[] = [
            'label'  => $row['label'],
            'url'    => $row['url'],
            'target' => $row['target'],
        ];
    }
    return $items;
});

<?php

// ─── Admin sidebar ────────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'menu-manager' ? 'active' : '';
    echo '<a href="' . BASE_URL . '/admin/modules/menu-manager/" class="nav-link ' . $isActive . '">'
       . '<i class="bi bi-list-ul"></i> Menu Beheer</a>';
});

// ─── Schema migration (voeg source + page_id toe als ze ontbreken) ────────────
add_action('modules_loaded', function () {
    if (Settings::get('menu_manager_schema_v2')) return;

    $db     = Database::getInstance();
    $prefix = DB_PREFIX;

    $cols     = $db->fetchAll("SHOW COLUMNS FROM `{$prefix}menu_items`") ?: [];
    $colNames = array_column($cols, 'Field');

    if (!in_array('source', $colNames)) {
        $db->query(
            "ALTER TABLE `{$prefix}menu_items`
             ADD COLUMN `source` VARCHAR(20) NOT NULL DEFAULT 'manual' AFTER `is_active`"
        );
    }
    if (!in_array('page_id', $colNames)) {
        $db->query(
            "ALTER TABLE `{$prefix}menu_items`
             ADD COLUMN `page_id` INT NULL DEFAULT NULL AFTER `source`"
        );
    }

    Settings::set('menu_manager_schema_v2', '1');
});

// ─── Sync CMS-pagina's naar menu_items ───────────────────────────────────────
if (!function_exists('menu_manager_sync_pages')) {
    function menu_manager_sync_pages(): void
    {
        $db     = Database::getInstance();
        $prefix = DB_PREFIX;

        // Controleer of de pagina-tabel bestaat
        $tables = $db->fetchAll("SHOW TABLES LIKE '{$prefix}pages'") ?: [];
        if (empty($tables)) return;

        $pages = $db->fetchAll(
            "SELECT id, title, slug FROM `{$prefix}pages` WHERE is_active = 1"
        ) ?: [];

        foreach ($pages as $page) {
            $url = '/' . ltrim($page['slug'], '/');

            // Voeg toe voor header als het item er nog niet is
            $exists = $db->fetch(
                "SELECT id FROM `{$prefix}menu_items` WHERE page_id = ? AND location = 'header'",
                [$page['id']]
            );
            if (!$exists) {
                $db->query(
                    "INSERT INTO `{$prefix}menu_items`
                        (label, url, location, sort_order, target, is_active, source, page_id)
                     VALUES (?, ?, 'header', 999, '_self', 0, 'page', ?)",
                    [$page['title'], $url, $page['id']]
                );
            }
        }
    }
}

// Sync uitvoeren bij laden van een admin-pagina
add_action('admin_init', function () {
    menu_manager_sync_pages();
});

// ─── Helper: fetch active items for a location ────────────────────────────────
if (!function_exists('get_menu_items')) {
    function get_menu_items(string $location): array
    {
        $db     = Database::getInstance();
        $prefix = DB_PREFIX;

        return $db->fetchAll(
            "SELECT * FROM `{$prefix}menu_items`
             WHERE location = ? AND is_active = 1
             ORDER BY sort_order ASC, id ASC",
            [$location]
        ) ?: [];
    }
}

// ─── Filter hooks: vervangen de standaard ROICT CMS-menu's ───────────────────
// Wanneer menu-manager actief is, worden de standaard nav-items genegeerd
// en vervangen door wat in menu-manager staat.
add_filter('header_nav_items', function (array $items): array {
    $managed = get_menu_items('header');
    if (empty($managed)) return $items; // Geen items? Val terug op standaard

    return array_map(fn($row) => [
        'label'  => $row['label'],
        'url'    => $row['url'],
        'target' => $row['target'],
    ], $managed);
});

add_filter('footer_nav_items', function (array $items): array {
    $managed = get_menu_items('footer');
    if (empty($managed)) return $items; // Geen items? Val terug op standaard

    return array_map(fn($row) => [
        'label'  => $row['label'],
        'url'    => $row['url'],
        'target' => $row['target'],
    ], $managed);
});

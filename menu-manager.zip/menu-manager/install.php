<?php
$db     = Database::getInstance();
$prefix = DB_PREFIX;

$db->query("
    CREATE TABLE IF NOT EXISTS `{$prefix}menu_items` (
        `id`         INT AUTO_INCREMENT PRIMARY KEY,
        `label`      VARCHAR(255) NOT NULL,
        `url`        VARCHAR(500) NOT NULL,
        `location`   ENUM('header','footer') NOT NULL DEFAULT 'header',
        `sort_order` INT NOT NULL DEFAULT 0,
        `target`     VARCHAR(10) NOT NULL DEFAULT '_self',
        `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
        `source`     VARCHAR(20) NOT NULL DEFAULT 'manual',
        `page_id`    INT NULL DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
");

<?php
$db     = Database::getInstance();
$prefix = DB_PREFIX;

$db->query("DROP TABLE IF EXISTS `{$prefix}menu_items`");

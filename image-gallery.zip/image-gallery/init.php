<?php
// Geen frontend-hooks nodig; de widget wordt via functions.php aangeroepen.

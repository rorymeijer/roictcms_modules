<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'faq' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/faq/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-question-circle me-2"></i>FAQ</a>';
});

// FAQ-assets laden
add_action('frontend_head', function () {
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/faq/assets/css/faq.css">';
});

<?php
// FAQ-assets laden
add_action('frontend_head', function () {
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/faq/assets/css/faq.css">';
});

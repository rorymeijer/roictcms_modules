<?php
add_action('frontend_init', function () {
    $db  = Database::getInstance();
    $uri = '/' . ltrim(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    $row = $db->fetch(
        "SELECT * FROM `" . DB_PREFIX . "redirects` WHERE source = ? AND active = 1 LIMIT 1",
        [$uri]
    );
    if ($row) {
        if (Settings::get('redirects_log_hits', '1') === '1') {
            $db->query("UPDATE `" . DB_PREFIX . "redirects` SET hits = hits + 1 WHERE id = ?", [$row['id']]);
        }
        header('Location: ' . $row['destination'], true, (int)$row['type']);
        exit;
    }
});

<?php
function social_share_render(string $url = '', string $title = ''): string {
    $url   = $url   ?: (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $title = $title ?: Settings::get('site_name', '');
    $eu    = urlencode($url);
    $et    = urlencode($title);

    $buttons = '';
    if (Settings::get('social_share_facebook', '1') === '1') {
        $buttons .= '<a class="social-share-btn" style="background:#1877f2;" href="https://www.facebook.com/sharer/sharer.php?u=' . $eu . '" target="_blank" rel="noopener"><i class="bi bi-facebook"></i> Facebook</a>';
    }
    if (Settings::get('social_share_twitter', '1') === '1') {
        $buttons .= '<a class="social-share-btn" style="background:#000;" href="https://twitter.com/intent/tweet?url=' . $eu . '&text=' . $et . '" target="_blank" rel="noopener"><i class="bi bi-twitter-x"></i> X</a>';
    }
    if (Settings::get('social_share_linkedin', '1') === '1') {
        $buttons .= '<a class="social-share-btn" style="background:#0a66c2;" href="https://www.linkedin.com/sharing/share-offsite/?url=' . $eu . '" target="_blank" rel="noopener"><i class="bi bi-linkedin"></i> LinkedIn</a>';
    }
    if (Settings::get('social_share_whatsapp', '1') === '1') {
        $buttons .= '<a class="social-share-btn" style="background:#25d366;" href="https://api.whatsapp.com/send?text=' . $et . '%20' . $eu . '" target="_blank" rel="noopener"><i class="bi bi-whatsapp"></i> WhatsApp</a>';
    }

    return $buttons ? '<div class="social-share-buttons">' . $buttons . '</div>' : '';
}

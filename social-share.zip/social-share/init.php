<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'social-share' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/social-share/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-share me-2"></i>Social Share</a>';
});

// Assets laden
add_action('frontend_head', function () {
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/social-share/assets/css/social-share.css">';
});

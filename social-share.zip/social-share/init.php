<?php
// Assets laden
add_action('frontend_head', function () {
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/social-share/assets/css/social-share.css">';
});

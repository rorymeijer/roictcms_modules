<?php
Settings::setMultiple([
    'social_share_facebook'  => '1',
    'social_share_twitter'   => '1',
    'social_share_linkedin'  => '1',
    'social_share_whatsapp'  => '1',
    'social_share_position'  => 'bottom',
]);

<?php
$db = Database::getInstance();
foreach (['social_share_facebook','social_share_twitter','social_share_linkedin','social_share_whatsapp','social_share_position'] as $k) {
    $db->delete(DB_PREFIX . 'settings', '`key` = ?', [$k]);
}

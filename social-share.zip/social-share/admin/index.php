<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();
require_once dirname(__DIR__) . '/functions.php';

$pageTitle = 'Social Share';
$activePage = 'social-share';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { flash('error', 'Ongeldige aanvraag.'); redirect(BASE_URL . '/admin/social-share/'); }
    Settings::setMultiple([
        'social_share_facebook'  => isset($_POST['facebook'])  ? '1' : '0',
        'social_share_twitter'   => isset($_POST['twitter'])   ? '1' : '0',
        'social_share_linkedin'  => isset($_POST['linkedin'])  ? '1' : '0',
        'social_share_whatsapp'  => isset($_POST['whatsapp'])  ? '1' : '0',
        'social_share_position'  => $_POST['position'] ?? 'bottom',
    ]);
    flash('success', 'Instellingen opgeslagen.');
    redirect(BASE_URL . '/admin/social-share/');
}

require_once ADMIN_PATH . '/includes/header.php';
?>
<div class="page-header"><h1><i class="bi bi-share"></i> <?= e($pageTitle) ?></h1></div>
<?= renderFlash() ?>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card">
            <div class="card-body">
                <form method="POST">
                    <?= csrf_field() ?>
                    <h6 class="mb-3">Platforms</h6>
                    <?php foreach (['facebook'=>'Facebook','twitter'=>'X (Twitter)','linkedin'=>'LinkedIn','whatsapp'=>'WhatsApp'] as $k=>$label): ?>
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" name="<?= $k ?>" id="<?= $k ?>"
                               <?= Settings::get('social_share_' . $k, '1') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="<?= $k ?>"><?= $label ?></label>
                    </div>
                    <?php endforeach; ?>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label">Positie op pagina</label>
                        <select name="position" class="form-select">
                            <option value="bottom" <?= Settings::get('social_share_position','bottom') === 'bottom' ? 'selected':'' ?>>Onder de inhoud</option>
                            <option value="top"    <?= Settings::get('social_share_position','bottom') === 'top'    ? 'selected':'' ?>>Boven de inhoud</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-save"></i> Opslaan</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card">
            <div class="card-header"><strong>Voorbeeld</strong></div>
            <div class="card-body">
                <link rel="stylesheet" href="<?= e(BASE_URL) ?>/modules/social-share/assets/css/social-share.css">
                <?= social_share_render(BASE_URL, Settings::get('site_name', 'Mijn website')) ?>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-header"><strong>Gebruik in thema</strong></div>
            <div class="card-body">
                <pre class="bg-light p-2 rounded small"><code>&lt;?php
require_once MODULES_PATH . '/social-share/functions.php';
echo social_share_render();
?&gt;</code></pre>
            </div>
        </div>
    </div>
</div>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

<?php
$db = Database::getInstance();
$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "custom_fields` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `object_type` VARCHAR(50) NOT NULL DEFAULT 'page',
    `object_id` INT UNSIGNED NOT NULL,
    `field_key` VARCHAR(100) NOT NULL,
    `field_value` LONGTEXT DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `object_field` (`object_type`, `object_id`, `field_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'custom-fields' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/custom-fields/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-layout-text-sidebar-reverse me-2"></i>Custom Fields</a>';
});

function get_custom_field(string $type, int $id, string $key, string $default = ''): string {
    $row = Database::getInstance()->fetch(
        "SELECT field_value FROM `" . DB_PREFIX . "custom_fields` WHERE object_type=? AND object_id=? AND field_key=?",
        [$type, $id, $key]
    );
    return $row ? (string)$row['field_value'] : $default;
}

<?php
function get_custom_field(string $type, int $id, string $key, string $default = ''): string {
    $row = Database::getInstance()->fetch(
        "SELECT field_value FROM `" . DB_PREFIX . "custom_fields` WHERE object_type=? AND object_id=? AND field_key=?",
        [$type, $id, $key]
    );
    return $row ? (string)$row['field_value'] : $default;
}

<?php
Database::getInstance()->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "custom_fields`");

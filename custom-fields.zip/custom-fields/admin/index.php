<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();

$db        = Database::getInstance();
$pageTitle = 'Custom Fields';
$activePage = 'custom-fields';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { flash('error', 'Ongeldige aanvraag.'); redirect(BASE_URL . '/admin/custom-fields/'); }
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $objectType = trim($_POST['object_type'] ?? 'page');
        $objectId   = (int)($_POST['object_id'] ?? 0);
        $key        = preg_replace('/[^a-z0-9_]/', '_', strtolower(trim($_POST['field_key'] ?? '')));
        $value      = $_POST['field_value'] ?? '';
        if ($key && $objectId > 0) {
            $existing = $db->fetch(
                "SELECT id FROM `" . DB_PREFIX . "custom_fields` WHERE object_type=? AND object_id=? AND field_key=?",
                [$objectType, $objectId, $key]
            );
            if ($existing) {
                $db->update(DB_PREFIX . 'custom_fields', ['field_value'=>$value], 'id=?', [$existing['id']]);
            } else {
                $db->insert(DB_PREFIX . 'custom_fields', ['object_type'=>$objectType,'object_id'=>$objectId,'field_key'=>$key,'field_value'=>$value]);
            }
            flash('success', 'Veld opgeslagen.');
        }
    }
    if ($action === 'delete') {
        $db->delete(DB_PREFIX . 'custom_fields', 'id=?', [(int)$_POST['field_id']]);
        flash('success', 'Veld verwijderd.');
    }
    redirect(BASE_URL . '/admin/custom-fields/?' . http_build_query(['type'=>$_POST['object_type']??'page','id'=>$_POST['object_id']??0]));
}

$filterType = $_GET['type'] ?? 'page';
$filterId   = (int)($_GET['id'] ?? 0);
$pages      = $db->fetchAll("SELECT id, title FROM `" . DB_PREFIX . "pages` ORDER BY title");
$fields     = $filterId ? $db->fetchAll(
    "SELECT * FROM `" . DB_PREFIX . "custom_fields` WHERE object_type=? AND object_id=? ORDER BY field_key",
    [$filterType, $filterId]
) : [];

require_once ADMIN_PATH . '/includes/header.php';
?>
<div class="page-header"><h1><i class="bi bi-layout-text-sidebar-reverse"></i> <?= e($pageTitle) ?></h1></div>
<?= renderFlash() ?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card mb-3">
            <div class="card-header"><strong>Selecteer pagina</strong></div>
            <div class="card-body">
                <form method="GET">
                    <input type="hidden" name="type" value="page">
                    <div class="mb-2">
                        <select name="id" class="form-select">
                            <option value="">— Kies pagina —</option>
                            <?php foreach ($pages as $p): ?>
                                <option value="<?= (int)$p['id'] ?>" <?= $filterId===(int)$p['id']?'selected':'' ?>><?= e($p['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-outline-primary w-100">Laden</button>
                </form>
            </div>
        </div>

        <?php if ($filterId): ?>
        <div class="card">
            <div class="card-header"><strong>Veld toevoegen/bijwerken</strong></div>
            <div class="card-body">
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="object_type" value="<?= e($filterType) ?>">
                    <input type="hidden" name="object_id" value="<?= $filterId ?>">
                    <div class="mb-2">
                        <label class="form-label">Sleutel</label>
                        <input type="text" name="field_key" class="form-control" placeholder="bv. phone_number" pattern="[a-zA-Z0-9_]+" required>
                        <div class="form-text">Letters, cijfers en underscores.</div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Waarde</label>
                        <textarea name="field_value" class="form-control" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-plus-lg"></i> Opslaan</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-8">
        <?php if ($filterId): ?>
        <div class="card mb-3">
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead><tr><th>Sleutel</th><th>Waarde</th><th></th></tr></thead>
                    <tbody>
                        <?php foreach ($fields as $f): ?>
                        <tr>
                            <td><code><?= e($f['field_key']) ?></code></td>
                            <td class="text-truncate" style="max-width:300px;"><?= e($f['field_value']) ?></td>
                            <td>
                                <form method="POST" onsubmit="return confirm('Verwijderen?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="field_id" value="<?= (int)$f['id'] ?>">
                                    <input type="hidden" name="object_type" value="<?= e($filterType) ?>">
                                    <input type="hidden" name="object_id" value="<?= $filterId ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($fields)): ?><tr><td colspan="3" class="text-center text-muted py-4">Geen velden voor dit object.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><strong>Gebruik in thema</strong></div>
            <div class="card-body">
                <pre class="bg-light p-2 rounded small"><code>&lt;?php echo get_custom_field('page', $page['id'], 'phone_number'); ?&gt;</code></pre>
            </div>
        </div>
        <?php else: ?>
            <div class="card"><div class="card-body text-center text-muted py-5">Selecteer een pagina links.</div></div>
        <?php endif; ?>
    </div>
</div>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

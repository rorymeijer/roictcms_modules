<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();

$db        = Database::getInstance();
$pageTitle = 'Newsletter';
$activePage = 'newsletter';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { flash('error', 'Ongeldige aanvraag.'); redirect(BASE_URL . '/admin/modules/newsletter/'); }
    $action = $_POST['action'] ?? '';

    if ($action === 'delete_subscriber') {
        $db->delete(DB_PREFIX . 'newsletter_subscribers', 'id=?', [(int)$_POST['sub_id']]);
        flash('success', 'Abonnee verwijderd.');
    }

    if ($action === 'send_campaign') {
        $subject = trim($_POST['subject'] ?? '');
        $body    = trim($_POST['body']    ?? '');
        if ($subject && $body) {
            $subs = $db->fetchAll("SELECT * FROM `" . DB_PREFIX . "newsletter_subscribers` WHERE status='active'");
            $from = Settings::get('newsletter_from_name', '') . ' <' . Settings::get('newsletter_from_email', '') . '>';
            $sent = 0;
            foreach ($subs as $sub) {
                $unsubUrl  = BASE_URL . '/?newsletter_unsubscribe=' . $sub['token'];
                $bodyFinal = $body . "\n\n---\nUitschrijven: " . $unsubUrl;
                $headers   = "From: {$from}\r\nContent-Type: text/plain; charset=utf-8";
                if (@mail($sub['email'], $subject, $bodyFinal, $headers)) $sent++;
            }
            $db->insert(DB_PREFIX . 'newsletter_campaigns', [
                'subject'          => $subject,
                'body'             => $body,
                'sent_at'          => date('Y-m-d H:i:s'),
                'recipient_count'  => $sent,
            ]);
            flash('success', "Campagne verstuurd naar {$sent} abonnee(s).");
        }
    }

    if ($action === 'save_settings') {
        Settings::setMultiple([
            'newsletter_from_name'  => trim($_POST['from_name']  ?? ''),
            'newsletter_from_email' => trim($_POST['from_email'] ?? ''),
        ]);
        flash('success', 'Instellingen opgeslagen.');
    }

    redirect(BASE_URL . '/admin/modules/newsletter/');
}

$tab        = $_GET['tab'] ?? 'subscribers';
$subscribers = $db->fetchAll("SELECT * FROM `" . DB_PREFIX . "newsletter_subscribers` ORDER BY subscribed_at DESC");
$campaigns  = $db->fetchAll("SELECT * FROM `" . DB_PREFIX . "newsletter_campaigns` ORDER BY created_at DESC");
$active     = count(array_filter($subscribers, fn($s) => $s['status'] === 'active'));

require_once ADMIN_PATH . '/includes/header.php';
?>
<div class="page-header d-flex justify-content-between align-items-center">
    <h1><i class="bi bi-mailbox"></i> <?= e($pageTitle) ?></h1>
    <span class="badge bg-primary fs-6"><?= $active ?> actieve abonnee(s)</span>
</div>
<?= renderFlash() ?>

<ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link <?= $tab === 'subscribers' ? 'active' : '' ?>" href="?tab=subscribers">Abonnees</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'campaigns'   ? 'active' : '' ?>" href="?tab=campaigns">Campagnes</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'settings'    ? 'active' : '' ?>" href="?tab=settings">Instellingen</a></li>
</ul>

<?php if ($tab === 'subscribers'): ?>
<div class="card">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead><tr><th>E-mail</th><th>Naam</th><th>Status</th><th>Datum</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($subscribers as $s): ?>
                <tr>
                    <td><?= e($s['email']) ?></td>
                    <td><?= e($s['name'] ?: '—') ?></td>
                    <td><span class="badge <?= $s['status'] === 'active' ? 'bg-success' : 'bg-secondary' ?>"><?= e($s['status']) ?></span></td>
                    <td><?= date('d-m-Y', strtotime($s['subscribed_at'])) ?></td>
                    <td>
                        <form method="POST" onsubmit="return confirm('Verwijderen?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete_subscriber">
                            <input type="hidden" name="sub_id" value="<?= (int)$s['id'] ?>">
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($subscribers)): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">Geen abonnees.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php elseif ($tab === 'campaigns'): ?>
<div class="row g-4">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header"><strong>Nieuwe campagne versturen</strong></div>
            <div class="card-body">
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="send_campaign">
                    <div class="mb-2">
                        <label class="form-label">Onderwerp</label>
                        <input type="text" name="subject" class="form-control" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Bericht (platte tekst)</label>
                        <textarea name="body" class="form-control" rows="6" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100"
                            onclick="return confirm('Versturen naar alle actieve abonnees?')">
                        <i class="bi bi-send"></i> Versturen (<?= $active ?> ontvangers)
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card">
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <thead><tr><th>Onderwerp</th><th>Ontvangers</th><th>Verstuurd</th></tr></thead>
                    <tbody>
                        <?php foreach ($campaigns as $c): ?>
                        <tr>
                            <td><?= e($c['subject']) ?></td>
                            <td><?= (int)$c['recipient_count'] ?></td>
                            <td><?= $c['sent_at'] ? date('d-m-Y H:i', strtotime($c['sent_at'])) : '—' ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($campaigns)): ?>
                            <tr><td colspan="3" class="text-center text-muted py-3">Nog geen campagnes.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<div class="card" style="max-width:500px;">
    <div class="card-body">
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_settings">
            <div class="mb-3">
                <label class="form-label">Afzendernaam</label>
                <input type="text" name="from_name" class="form-control"
                       value="<?= e(Settings::get('newsletter_from_name', '')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Afzender e-mailadres</label>
                <input type="email" name="from_email" class="form-control"
                       value="<?= e(Settings::get('newsletter_from_email', '')) ?>">
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Opslaan</button>
        </form>
        <hr>
        <p class="fw-semibold small mb-1">Gebruik in paginacontent (shortcode):</p>
        <pre class="bg-light p-2 rounded small mb-1"><code>[newsletter]</code></pre>
        <p class="text-muted small mb-3">Plak deze tag in de content van een pagina of bericht. Het inschrijfformulier wordt automatisch op die plek weergegeven.</p>

        <p class="fw-semibold small mb-1">Gebruik in een thema-template (PHP):</p>
        <pre class="bg-light p-2 rounded small mb-0"><code>&lt;?= newsletter_form() ?&gt;</code></pre>
    </div>
</div>
<?php endif; ?>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

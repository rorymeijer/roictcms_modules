<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'newsletter' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/newsletter/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-mailbox me-2"></i>Newsletter</a>';
});

// ── Laad module CSS in <head> ─────────────────────────────────────────────────
add_action('theme_head', function () {
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/newsletter/assets/css/form.css">' . PHP_EOL;
});

// ── Frontend: verwerk inschrijfformulier ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_nl_action'] ?? '') === 'subscribe') {
    NewsletterModule::handleSubscribe();
}

// Afmeld-route: /?newsletter_unsubscribe=<token>
if (!empty($_GET['newsletter_unsubscribe'])) {
    $token = preg_replace('/[^a-f0-9]/', '', $_GET['newsletter_unsubscribe']);
    if ($token) {
        Database::getInstance()->update(
            DB_PREFIX . 'newsletter_subscribers',
            ['status' => 'unsubscribed'],
            'token = ?',
            [$token]
        );
    }
    die('<p style="font-family:sans-serif;text-align:center;margin-top:3rem">Je bent succesvol uitgeschreven. <a href="' . BASE_URL . '">Terug naar de website</a></p>');
}

// ── Module class ───────────────────────────────────────────────────────────────
class NewsletterModule
{
    // ── Render het inschrijfformulier ──────────────────────────────────────────
    public static function renderForm(): string
    {
        $success = isset($_GET['nl_subscribed']);
        $error   = $_SESSION['nl_error'] ?? null;
        unset($_SESSION['nl_error']);
        $oldEmail = $_SESSION['nl_old_email'] ?? '';
        $oldName  = $_SESSION['nl_old_name']  ?? '';
        unset($_SESSION['nl_old_email'], $_SESSION['nl_old_name']);

        ob_start(); ?>
        <div class="nl-wrap" id="newsletter-form">
            <?php if ($success): ?>
            <div class="nl-success">
                <span class="nl-success-icon">✓</span>
                <p>Bedankt voor uw inschrijving!</p>
            </div>
            <?php else: ?>

            <?php if ($error): ?>
            <div class="nl-error-banner"><?= e($error) ?></div>
            <?php endif; ?>

            <form class="nl-form" method="POST" action="<?= e(strtok($_SERVER['REQUEST_URI'], '?')) ?>#newsletter-form" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="_nl_action" value="subscribe">

                <!-- Honeypot — niet invullen -->
                <div class="nl-hp" aria-hidden="true">
                    <input type="text" name="nl_website" tabindex="-1" autocomplete="off">
                </div>

                <div class="nl-row nl-row--2">
                    <div class="nl-field">
                        <label for="nl_name">Naam</label>
                        <input type="text" id="nl_name" name="nl_name"
                               value="<?= e($oldName) ?>"
                               placeholder="Uw naam" maxlength="100">
                    </div>
                    <div class="nl-field">
                        <label for="nl_email">E-mailadres <span>*</span></label>
                        <input type="email" id="nl_email" name="nl_email"
                               value="<?= e($oldEmail) ?>"
                               placeholder="u@voorbeeld.nl" required maxlength="255">
                    </div>
                </div>

                <div class="nl-submit">
                    <button type="submit" class="nl-btn">
                        <span>Inschrijven</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z"/>
                        </svg>
                    </button>
                    <p class="nl-privacy">Uw gegevens worden vertrouwelijk behandeld. U kunt zich altijd uitschrijven.</p>
                </div>
            </form>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // ── Verwerk inschrijving ───────────────────────────────────────────────────
    public static function handleSubscribe(): void
    {
        // CSRF
        if (!csrf_verify()) {
            self::failBack('Beveiligingsfout. Probeer opnieuw.');
        }

        // Honeypot
        if (!empty($_POST['nl_website'])) {
            self::redirectSuccess();
        }

        $email = trim($_POST['nl_email'] ?? '');
        $name  = trim($_POST['nl_name']  ?? '');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            self::failBack('Vul een geldig e-mailadres in.', $email, $name);
        }

        $db = Database::getInstance();

        // Controleer op bestaand actief abonnement
        $existing = $db->fetch(
            "SELECT id, status FROM `" . DB_PREFIX . "newsletter_subscribers` WHERE email = ?",
            [$email]
        );

        if ($existing) {
            if ($existing['status'] === 'active') {
                self::failBack('Dit e-mailadres is al ingeschreven.');
            }
            // Heractiveer uitgeschreven abonnee
            $db->update(
                DB_PREFIX . 'newsletter_subscribers',
                ['status' => 'active', 'name' => $name ?: null],
                'id = ?',
                [$existing['id']]
            );
        } else {
            $token = bin2hex(random_bytes(32));
            $db->insert(DB_PREFIX . 'newsletter_subscribers', [
                'email'  => $email,
                'name'   => $name ?: null,
                'status' => 'active',
                'token'  => $token,
            ]);
        }

        self::redirectSuccess();
    }

    private static function failBack(string $msg, string $email = '', string $name = ''): never
    {
        $_SESSION['nl_error']     = $msg;
        $_SESSION['nl_old_email'] = $email;
        $_SESSION['nl_old_name']  = $name;
        $url = strtok($_SERVER['REQUEST_URI'], '?');
        redirect($url . '#newsletter-form');
    }

    private static function redirectSuccess(): never
    {
        $url = strtok($_SERVER['REQUEST_URI'], '?');
        redirect($url . '?nl_subscribed=1#newsletter-form');
    }
}

// ── Helper-functie voor gebruik in thema-templates ────────────────────────────
// echo newsletter_form();
function newsletter_form(): string
{
    return NewsletterModule::renderForm();
}

// ── Registreer [newsletter] shortcode voor gebruik in CMS-paginacontent ───────
add_shortcode('newsletter', 'newsletter_form');

<?php
// Afmeld-route: /?newsletter_unsubscribe=<token>
if (!empty($_GET['newsletter_unsubscribe'])) {
    $token = preg_replace('/[^a-f0-9]/', '', $_GET['newsletter_unsubscribe']);
    if ($token) {
        Database::getInstance()->update(
            DB_PREFIX . 'newsletter_subscribers',
            ['status' => 'unsubscribed'],
            'token = ?',
            [$token]
        );
    }
    die('<p style="font-family:sans-serif;text-align:center;margin-top:3rem">Je bent succesvol uitgeschreven. <a href="' . BASE_URL . '">Terug naar de website</a></p>');
}

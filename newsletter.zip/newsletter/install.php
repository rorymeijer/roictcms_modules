<?php
$db = Database::getInstance();
$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "newsletter_subscribers` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `name` VARCHAR(100) DEFAULT NULL,
    `status` ENUM('active','unsubscribed') NOT NULL DEFAULT 'active',
    `token` VARCHAR(64) NOT NULL,
    `subscribed_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "newsletter_campaigns` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `subject` VARCHAR(255) NOT NULL,
    `body` LONGTEXT NOT NULL,
    `sent_at` DATETIME DEFAULT NULL,
    `recipient_count` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

Settings::set('newsletter_from_name',  Settings::get('site_name', 'Website'));
Settings::set('newsletter_from_email', Settings::get('admin_email', ''));

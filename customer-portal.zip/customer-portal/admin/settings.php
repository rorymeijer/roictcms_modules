<?php
/**
 * Customer Portal – admin/settings.php
 * Module-instellingen.
 */

$action = $_POST['action'] ?? '';

if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $keys = [
        'cp_portal_slug', 'cp_login_slug', 'cp_company_name', 'cp_company_address',
        'cp_company_postcode', 'cp_company_city', 'cp_company_kvk',
        'cp_company_btw', 'cp_company_iban', 'cp_invoice_prefix',
        'cp_quote_prefix', 'cp_payment_days', 'cp_quote_valid_days',
        'cp_tax_rate', 'cp_portal_enabled',
        'cp_mail_from_name', 'cp_mail_from_email',
        'cp_mail_invoice_subject', 'cp_mail_quote_subject',
    ];
    foreach ($keys as $key) {
        if (isset($_POST[$key])) {
            Settings::set($key, trim($_POST[$key]));
        }
    }
    flash('success', 'Instellingen opgeslagen.');
    redirect(BASE_URL . '/admin/modules/customer-portal/?page=settings');
}

$pageTitle  = 'Instellingen – Klantenpaneel';
$activePage = 'klantenpaneel-settings';

require_once ADMIN_PATH . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 style="font-size:1.4rem;font-weight:800;margin:0;">
            <i class="bi bi-gear me-2" style="color:var(--primary);"></i>Instellingen
        </h1>
        <p class="text-muted mb-0" style="font-size:.85rem;">Configureer het klantenpaneel</p>
    </div>
    <a href="<?= BASE_URL ?>/admin/modules/" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i>Terug naar modules
    </a>
</div>

<form method="post" action="<?= BASE_URL ?>/admin/modules/customer-portal/?page=settings">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <!-- Portaal -->
    <div class="cms-card mb-4">
        <div class="cms-card-header">
            <span class="cms-card-title">Frontend klantenpaneel</span>
        </div>
        <div class="cms-card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Portaal URL-slug</label>
                    <div class="input-group">
                        <span class="input-group-text" style="font-size:.8rem;"><?= BASE_URL ?></span>
                        <input type="text" name="cp_portal_slug" class="form-control"
                               value="<?= e(Settings::get('cp_portal_slug') ?: 'klanten-portaal') ?>">
                    </div>
                    <div class="form-text">Vereist actieve Frontend Login module.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Inlogpagina URL-slug</label>
                    <div class="input-group">
                        <span class="input-group-text" style="font-size:.8rem;"><?= BASE_URL ?>/</span>
                        <input type="text" name="cp_login_slug" class="form-control"
                               value="<?= e(Settings::get('cp_login_slug') ?: 'inloggen') ?>">
                    </div>
                    <div class="form-text">De pagina waar bezoekers naartoe gestuurd worden als ze niet zijn ingelogd.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Klantenpaneel actief</label>
                    <select name="cp_portal_enabled" class="form-select">
                        <option value="1" <?= Settings::get('cp_portal_enabled') === '1' ? 'selected' : '' ?>>Ja</option>
                        <option value="0" <?= Settings::get('cp_portal_enabled') !== '1' ? 'selected' : '' ?>>Nee</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Bedrijfsgegevens -->
    <div class="cms-card mb-4">
        <div class="cms-card-header">
            <span class="cms-card-title">Bedrijfsgegevens (op offertes en facturen)</span>
        </div>
        <div class="cms-card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Bedrijfsnaam</label>
                    <input type="text" name="cp_company_name" class="form-control" value="<?= e(Settings::get('cp_company_name')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">IBAN</label>
                    <input type="text" name="cp_company_iban" class="form-control" value="<?= e(Settings::get('cp_company_iban')) ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Adres</label>
                    <input type="text" name="cp_company_address" class="form-control" value="<?= e(Settings::get('cp_company_address')) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Postcode</label>
                    <input type="text" name="cp_company_postcode" class="form-control" value="<?= e(Settings::get('cp_company_postcode')) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Stad</label>
                    <input type="text" name="cp_company_city" class="form-control" value="<?= e(Settings::get('cp_company_city')) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">KVK-nummer</label>
                    <input type="text" name="cp_company_kvk" class="form-control" value="<?= e(Settings::get('cp_company_kvk')) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">BTW-nummer</label>
                    <input type="text" name="cp_company_btw" class="form-control" value="<?= e(Settings::get('cp_company_btw')) ?>">
                </div>
            </div>
        </div>
    </div>

    <!-- Nummering & BTW -->
    <div class="cms-card mb-4">
        <div class="cms-card-header">
            <span class="cms-card-title">Nummering &amp; BTW</span>
        </div>
        <div class="cms-card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Factuurprefix</label>
                    <input type="text" name="cp_invoice_prefix" class="form-control" value="<?= e(Settings::get('cp_invoice_prefix') ?: 'F') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Offerteprefix</label>
                    <input type="text" name="cp_quote_prefix" class="form-control" value="<?= e(Settings::get('cp_quote_prefix') ?: 'O') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Standaard BTW %</label>
                    <input type="number" name="cp_tax_rate" class="form-control" value="<?= e(Settings::get('cp_tax_rate') ?: '21') ?>" step="0.01">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Betalingstermijn (dagen)</label>
                    <input type="number" name="cp_payment_days" class="form-control" value="<?= e(Settings::get('cp_payment_days') ?: '14') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Offerte geldig (dagen)</label>
                    <input type="number" name="cp_quote_valid_days" class="form-control" value="<?= e(Settings::get('cp_quote_valid_days') ?: '30') ?>">
                </div>
            </div>
        </div>
    </div>

    <!-- E-mailinstellingen -->
    <div class="cms-card mb-4">
        <div class="cms-card-header">
            <span class="cms-card-title">E-mail verzending (facturen &amp; offertes)</span>
        </div>
        <div class="cms-card-body">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Afzendernaam</label>
                    <input type="text" name="cp_mail_from_name" class="form-control"
                           value="<?= e(Settings::get('cp_mail_from_name') ?: Settings::get('cp_company_name')) ?>"
                           placeholder="Uw bedrijfsnaam">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Afzenderadres</label>
                    <input type="email" name="cp_mail_from_email" class="form-control"
                           value="<?= e(Settings::get('cp_mail_from_email')) ?>"
                           placeholder="noreply@uwdomein.nl">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Onderwerp factuurmail</label>
                    <input type="text" name="cp_mail_invoice_subject" class="form-control"
                           value="<?= e(Settings::get('cp_mail_invoice_subject') ?: 'Uw factuur {nummer}') ?>">
                    <div class="form-text">Gebruik <code>{nummer}</code> voor het factuurnummer.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Onderwerp offertemail</label>
                    <input type="text" name="cp_mail_quote_subject" class="form-control"
                           value="<?= e(Settings::get('cp_mail_quote_subject') ?: 'Uw offerte {nummer}') ?>">
                    <div class="form-text">Gebruik <code>{nummer}</code> voor het offertenummer.</div>
                </div>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">
        <i class="bi bi-check-lg me-1"></i>Opslaan
    </button>
</form>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

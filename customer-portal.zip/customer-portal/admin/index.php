<?php
/**
 * Customer Portal – admin/index.php
 * Admin router: laadt de juiste subpagina op basis van ?page=
 */

require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();

$page    = $_GET['page'] ?? 'customers';
$allowed = ['customers', 'quotes', 'invoices', 'settings'];
$page    = in_array($page, $allowed) ? $page : 'customers';

require __DIR__ . '/' . $page . '.php';

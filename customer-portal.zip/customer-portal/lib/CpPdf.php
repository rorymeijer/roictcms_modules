<?php
/**
 * Customer Portal – lib/CpPdf.php
 * PDF-generatie voor facturen en offertes.
 * Vereist mPDF via Composer (composer require mpdf/mpdf).
 * Zonder mPDF wordt een print-vriendelijke HTML-pagina getoond als fallback.
 */
class CpPdf
{
    private static bool $checked       = false;
    private static bool $mpdfAvailable = false;

    // ----------------------------------------------------------------
    // mPDF beschikbaarheid
    // ----------------------------------------------------------------

    private static function init(): void
    {
        if (self::$checked) {
            return;
        }
        self::$checked = true;

        if (class_exists('\Mpdf\Mpdf')) {
            self::$mpdfAvailable = true;
            return;
        }

        $candidates = [];
        if (defined('ROOT_PATH')) {
            $candidates[] = ROOT_PATH . '/vendor/autoload.php';
            $candidates[] = dirname(ROOT_PATH) . '/vendor/autoload.php';
        }
        // Fallback: navigate up from this file's location
        // __DIR__ = .../modules/customer-portal/lib  →  3 levels up = public_html
        $candidates[] = dirname(__DIR__, 3) . '/vendor/autoload.php';
        $candidates[] = dirname(__DIR__, 4) . '/vendor/autoload.php';
        foreach ($candidates as $path) {
            if (file_exists($path)) {
                require_once $path;
                if (class_exists('\Mpdf\Mpdf')) {
                    self::$mpdfAvailable = true;
                    break;
                }
            }
        }
    }

    public static function available(): bool
    {
        self::init();
        return self::$mpdfAvailable;
    }

    // ----------------------------------------------------------------
    // HTML-sjabloon
    // ----------------------------------------------------------------

    /**
     * Genereer een zelfstandig HTML-document voor een factuur of offerte.
     *
     * @param string $type     'invoice' of 'quote'
     * @param array  $doc      Factuur/offerte record (incl. totalen)
     * @param array  $items    Regelitems
     * @param array  $customer Klant record
     */
    public static function renderDocument(string $type, array $doc, array $items, array $customer): string
    {
        $isInvoice = ($type === 'invoice');

        $companyName    = htmlspecialchars(Settings::get('cp_company_name')    ?: '');
        $companyAddress = htmlspecialchars(Settings::get('cp_company_address') ?: '');
        $companyPc      = htmlspecialchars(Settings::get('cp_company_postcode') ?: '');
        $companyCity    = htmlspecialchars(Settings::get('cp_company_city')    ?: '');
        $companyKvk     = htmlspecialchars(Settings::get('cp_company_kvk')     ?: '');
        $companyBtw     = htmlspecialchars(Settings::get('cp_company_btw')     ?: '');
        $companyIban    = htmlspecialchars(Settings::get('cp_company_iban')    ?: '');

        $docNumber   = htmlspecialchars($isInvoice ? ($doc['invoice_number'] ?? '') : ($doc['quote_number'] ?? ''));
        $docDate     = $isInvoice ? ($doc['invoice_date'] ?? date('Y-m-d')) : ($doc['created_at'] ?? date('Y-m-d'));
        $docExpiry   = $isInvoice ? ($doc['due_date'] ?? null) : ($doc['valid_until'] ?? null);
        $expiryLabel = $isInvoice ? 'Vervaldatum' : 'Geldig tot';
        $typeLabel   = $isInvoice ? 'FACTUUR' : 'OFFERTE';

        $subtotal  = (float)($doc['subtotal']   ?? 0);
        $discount  = (float)($doc['discount']   ?? 0);
        $taxAmount = (float)($doc['tax_amount'] ?? 0);
        $total     = (float)($doc['total']      ?? 0);
        $taxRate   = $doc['tax_rate'] ?? 21;

        $cName    = htmlspecialchars($customer['contact_name'] ?? '');
        $cCompany = htmlspecialchars($customer['company_name'] ?? '');
        $cAddress = htmlspecialchars($customer['address']      ?? '');
        $cPc      = htmlspecialchars($customer['postcode']     ?? '');
        $cCity    = htmlspecialchars($customer['city']         ?? '');
        $cEmail   = htmlspecialchars($customer['email']        ?? '');

        $docTitle = htmlspecialchars($doc['title'] ?? '');
        $docIntro = nl2br(htmlspecialchars($doc['intro'] ?? ''));
        $docFooter = nl2br(htmlspecialchars($doc['footer'] ?? ''));

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: DejaVu Sans, Arial, sans-serif; font-size:10pt; color:#1a202c; background:#fff; }

/* ── Header ── */
.hd { background:#1e3a5f; color:#fff; padding:24px 28px 20px; }
.hd-table { width:100%; border-collapse:collapse; }
.co-name { font-size:15pt; font-weight:bold; margin-bottom:4px; }
.co-meta { font-size:7.5pt; line-height:1.65; opacity:.85; }
.doc-type { font-size:26pt; font-weight:bold; letter-spacing:2px; line-height:1; text-align:right; }
.doc-num  { font-size:10pt; opacity:.85; text-align:right; margin-top:4px; }

/* ── Accent bar ── */
.accent { height:4px; background:linear-gradient(90deg,#3b82f6,#60a5fa); }

/* ── Info-rij ── */
.info { padding:20px 28px; display:table; width:100%; }
.ic   { display:table-cell; vertical-align:top; width:50%; }
.ic-r { padding-left:24px; }
.lbl  { font-size:7pt; text-transform:uppercase; letter-spacing:.8px; color:#718096; font-weight:bold; margin-bottom:5px; }
.val  { font-size:9.5pt; line-height:1.7; }
.meta-tbl { width:100%; border-collapse:collapse; }
.meta-tbl td { padding:3px 4px; font-size:9pt; }
.meta-tbl td:last-child { text-align:right; font-weight:bold; }
.meta-key { color:#718096; font-weight:normal !important; }

/* ── Intro ── */
.intro-box { padding:12px 28px; background:#f8fafc; font-size:9pt; color:#4a5568; line-height:1.6; border-bottom:1px solid #e2e8f0; }

/* ── Items ── */
.items { padding:20px 28px 8px; }
.doc-title { font-size:10.5pt; font-weight:bold; color:#1e3a5f; margin-bottom:10px; }
.it { width:100%; border-collapse:collapse; }
.it th { background:#1e3a5f; color:#fff; padding:8px 10px; font-size:8pt; font-weight:bold; text-align:left; }
.it th.r { text-align:right; }
.it th.c { text-align:center; }
.it td { padding:7px 10px; font-size:9pt; border-bottom:1px solid #e2e8f0; }
.it td.r { text-align:right; }
.it td.c { text-align:center; }
.it tr.even td { background:#f8fafc; }

/* ── Totalen ── */
.totals { padding:4px 28px 22px; }
.tot-tbl { width:240px; margin-left:auto; border-collapse:collapse; }
.tot-tbl td { padding:4px 6px; font-size:9.5pt; }
.tot-tbl td.r { text-align:right; }
.tot-key { color:#718096; }
.tot-row td { font-size:12pt; font-weight:bold; color:#1e3a5f; padding-top:9px !important; border-top:2px solid #1e3a5f; }

/* ── Footer ── */
.doc-footer { margin:0 28px; padding:14px 0; border-top:1px solid #e2e8f0; font-size:8pt; color:#718096; line-height:1.7; }
.bot-bar { background:#1e3a5f; height:6px; }
</style>
</head>
<body>

<!-- HEADER -->
<div class="hd">
  <table class="hd-table">
    <tr>
      <td style="vertical-align:top;">
        <?php if ($companyName): ?><div class="co-name"><?= $companyName ?></div><?php endif; ?>
        <div class="co-meta">
          <?php if ($companyAddress): ?><?= $companyAddress ?><br><?php endif; ?>
          <?php if ($companyPc || $companyCity): ?><?= $companyPc ?> <?= $companyCity ?><br><?php endif; ?>
          <?php if ($companyKvk): ?>KVK: <?= $companyKvk ?><?php if ($companyBtw): ?> &nbsp;|&nbsp; <?php endif; ?><?php endif; ?>
          <?php if ($companyBtw): ?>BTW: <?= $companyBtw ?><?php endif; ?>
        </div>
      </td>
      <td style="vertical-align:top;">
        <div class="doc-type"><?= $typeLabel ?></div>
        <div class="doc-num"><?= $docNumber ?></div>
      </td>
    </tr>
  </table>
</div>
<div class="accent"></div>

<!-- INFO-RIJ -->
<div class="info">
  <div class="ic">
    <div class="lbl"><?= $isInvoice ? 'Factuur voor' : 'Offerte voor' ?></div>
    <div class="val">
      <?php if ($cCompany): ?><strong><?= $cCompany ?></strong><br><?php endif; ?>
      <?= $cName ?>
      <?php if ($cAddress): ?><br><?= $cAddress ?><?php endif; ?>
      <?php if ($cPc || $cCity): ?><br><?= $cPc ?> <?= $cCity ?><?php endif; ?>
      <?php if ($cEmail): ?><br><?= $cEmail ?><?php endif; ?>
    </div>
  </div>
  <div class="ic ic-r">
    <table class="meta-tbl">
      <tr>
        <td class="meta-key"><?= $isInvoice ? 'Factuurnummer' : 'Offertenummer' ?>:</td>
        <td><?= $docNumber ?></td>
      </tr>
      <tr>
        <td class="meta-key"><?= $isInvoice ? 'Factuurdatum' : 'Datum' ?>:</td>
        <td><?= date('d-m-Y', strtotime($docDate)) ?></td>
      </tr>
      <?php if ($docExpiry): ?>
      <tr>
        <td class="meta-key"><?= $expiryLabel ?>:</td>
        <td><?= date('d-m-Y', strtotime($docExpiry)) ?></td>
      </tr>
      <?php endif; ?>
    </table>
  </div>
</div>

<?php if ($docIntro): ?>
<div class="intro-box"><?= $docIntro ?></div>
<?php endif; ?>

<!-- REGELS -->
<div class="items">
  <?php if ($docTitle): ?><div class="doc-title"><?= $docTitle ?></div><?php endif; ?>
  <table class="it">
    <thead>
      <tr>
        <th>Omschrijving</th>
        <th class="c" style="width:65px;">Aantal</th>
        <th class="r" style="width:95px;">Stuksprijs</th>
        <th class="r" style="width:95px;">Totaal</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $idx => $item): ?>
      <tr class="<?= $idx % 2 === 1 ? 'even' : '' ?>">
        <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
        <td class="c"><?= rtrim(rtrim(number_format((float)($item['quantity'] ?? 0), 2, ',', '.'), '0'), ',') ?></td>
        <td class="r">€&nbsp;<?= number_format((float)($item['unit_price'] ?? 0), 2, ',', '.') ?></td>
        <td class="r">€&nbsp;<?= number_format((float)($item['line_total'] ?? 0), 2, ',', '.') ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- TOTALEN -->
<div class="totals">
  <table class="tot-tbl">
    <tr>
      <td class="tot-key">Subtotaal</td>
      <td class="r">€&nbsp;<?= number_format($subtotal, 2, ',', '.') ?></td>
    </tr>
    <?php if ($discount > 0): ?>
    <tr>
      <td class="tot-key">Korting</td>
      <td class="r" style="color:#e53e3e;">-&nbsp;€&nbsp;<?= number_format($discount, 2, ',', '.') ?></td>
    </tr>
    <?php endif; ?>
    <tr>
      <td class="tot-key">BTW (<?= is_numeric($taxRate) && floor($taxRate) == $taxRate ? (int)$taxRate : $taxRate ?>%)</td>
      <td class="r">€&nbsp;<?= number_format($taxAmount, 2, ',', '.') ?></td>
    </tr>
    <tr class="tot-row">
      <td>Totaal</td>
      <td class="r">€&nbsp;<?= number_format($total, 2, ',', '.') ?></td>
    </tr>
  </table>
</div>

<!-- DOCUMENTVOET -->
<div class="doc-footer">
  <?php if ($docFooter): ?><p style="margin-bottom:6px;"><?= $docFooter ?></p><?php endif; ?>
  <?php if ($isInvoice && $companyIban): ?>
  <p>
    Betaling: Maak <strong>€&nbsp;<?= number_format($total, 2, ',', '.') ?></strong> over op
    <strong><?= $companyIban ?></strong> o.v.v. <strong><?= $docNumber ?></strong><?php if ($docExpiry): ?>, vóór <?= date('d-m-Y', strtotime($docExpiry)) ?><?php endif; ?>.
  </p>
  <?php endif; ?>
</div>
<div class="bot-bar"></div>

</body>
</html>
        <?php
        return ob_get_clean();
    }

    // ----------------------------------------------------------------
    // PDF uitvoer
    // ----------------------------------------------------------------

    /**
     * Geef PDF-bytes terug als string (vereist mPDF).
     * @throws \RuntimeException als mPDF niet beschikbaar is.
     */
    public static function toPdfString(string $html): string
    {
        self::init();
        if (!self::$mpdfAvailable) {
            throw new \RuntimeException('mPDF is niet beschikbaar. Installeer via Composer: composer require mpdf/mpdf');
        }
        $mpdf = new \Mpdf\Mpdf([
            'mode'          => 'utf-8',
            'format'        => 'A4',
            'margin_top'    => 0,
            'margin_bottom' => 0,
            'margin_left'   => 0,
            'margin_right'  => 0,
        ]);
        $mpdf->WriteHTML($html);
        return $mpdf->Output('', 'S');
    }

    /**
     * Stuur PDF direct als download naar de browser.
     * Valt terug op print-vriendelijke HTML als mPDF ontbreekt.
     */
    public static function download(string $html, string $filename): void
    {
        self::init();
        if (self::$mpdfAvailable) {
            $mpdf = new \Mpdf\Mpdf([
                'mode'          => 'utf-8',
                'format'        => 'A4',
                'margin_top'    => 0,
                'margin_bottom' => 0,
                'margin_left'   => 0,
                'margin_right'  => 0,
            ]);
            $mpdf->WriteHTML($html);
            $mpdf->Output($filename, 'D');
            exit;
        }

        // Fallback: open in browser met automatische printdialoog
        header('Content-Type: text/html; charset=utf-8');
        echo $html;
        echo '<script>window.onload=function(){window.print();}</script>';
        exit;
    }
}

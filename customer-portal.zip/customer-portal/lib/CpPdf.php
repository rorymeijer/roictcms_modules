<?php
/**
 * Customer Portal – lib/CpPdf.php
 * PDF-generatie voor facturen en offertes.
 * Gebruikt de ingebouwde CpPdfWriter – geen Composer of externe libraries vereist.
 */
class CpPdf
{
    // ── Kleurdefinities (RGB 0–1) ────────────────────────────────────

    private const C_DARK_BLUE   = [0.118, 0.227, 0.373];  // #1e3a5f
    private const C_ACCENT_BLUE = [0.231, 0.510, 0.965];  // #3b82f6
    private const C_GRAY        = [0.443, 0.502, 0.588];  // #718096
    private const C_LIGHT_BG    = [0.973, 0.980, 0.988];  // #f8fafc
    private const C_BORDER      = [0.886, 0.910, 0.941];  // #e2e8f0
    private const C_DARK_TEXT   = [0.102, 0.125, 0.173];  // #1a202c
    private const C_RED         = [0.898, 0.243, 0.243];  // #e53e3e
    private const C_WHITE       = [1.0, 1.0, 1.0];

    // ── Beschikbaarheid (altijd true – geen Composer vereist) ────────

    public static function available(): bool
    {
        return true;
    }

    // ── PDF-generatie ────────────────────────────────────────────────

    /**
     * Genereer een PDF voor een factuur of offerte en geef de bytes terug.
     *
     * @param string $type     'invoice' of 'quote'
     * @param array  $doc      Factuur/offerte record
     * @param array  $items    Regelitems
     * @param array  $customer Klant record
     */
    public static function documentToPdf(string $type, array $doc, array $items, array $customer): string
    {
        $isInvoice = ($type === 'invoice');

        // Bedrijfsgegevens
        $companyName    = Settings::get('cp_company_name')     ?: '';
        $companyAddress = Settings::get('cp_company_address')  ?: '';
        $companyPc      = Settings::get('cp_company_postcode') ?: '';
        $companyCity    = Settings::get('cp_company_city')     ?: '';
        $companyKvk     = Settings::get('cp_company_kvk')      ?: '';
        $companyBtw     = Settings::get('cp_company_btw')      ?: '';
        $companyIban    = Settings::get('cp_company_iban')      ?: '';

        // Document-gegevens
        $docNumber   = $isInvoice ? ($doc['invoice_number'] ?? '') : ($doc['quote_number'] ?? '');
        $docDate     = $isInvoice ? ($doc['invoice_date']   ?? date('Y-m-d')) : ($doc['created_at'] ?? date('Y-m-d'));
        $docExpiry   = $isInvoice ? ($doc['due_date']       ?? null) : ($doc['valid_until'] ?? null);
        $expiryLabel = $isInvoice ? 'Vervaldatum' : 'Geldig tot';
        $typeLabel   = $isInvoice ? 'FACTUUR' : 'OFFERTE';

        $subtotal  = (float)($doc['subtotal']   ?? 0);
        $discount  = (float)($doc['discount']   ?? 0);
        $taxAmount = (float)($doc['tax_amount'] ?? 0);
        $total     = (float)($doc['total']      ?? 0);
        $taxRate   = $doc['tax_rate'] ?? 21;

        // Klantgegevens
        $cName    = $customer['contact_name'] ?? '';
        $cCompany = $customer['company_name'] ?? '';
        $cAddress = $customer['address']      ?? '';
        $cPc      = $customer['postcode']     ?? '';
        $cCity    = $customer['city']         ?? '';
        $cEmail   = $customer['email']        ?? '';

        $docTitle  = $doc['title']  ?? '';
        $docIntro  = $doc['intro']  ?? '';
        $docFooter = $doc['footer'] ?? '';

        // ── PDF opbouwen ─────────────────────────────────────────────
        $p  = new CpPdfWriter();
        $ml = 28.0;                          // marge links
        $mr = 28.0;                          // marge rechts
        $pw = CpPdfWriter::PW;               // paginabreedte
        $cw = $pw - $ml - $mr;              // inhoudbreedte (539.28 pt)

        $p->addPage();

        // ── 1. HEADER (donkerblauw blok) ─────────────────────────────

        // Bereken header-hoogte op basis van meta-regels
        $metaLines = [];
        if ($companyAddress) $metaLines[] = $companyAddress;
        if ($companyPc || $companyCity) $metaLines[] = trim("{$companyPc} {$companyCity}");
        $kvkBtw = '';
        if ($companyKvk) $kvkBtw .= "KVK: {$companyKvk}";
        if ($companyBtw) $kvkBtw .= ($kvkBtw ? '  |  ' : '') . "BTW: {$companyBtw}";
        if ($kvkBtw) $metaLines[] = $kvkBtw;

        $headerH = max(72.0, 22.0 + 18.0 + 6.0 + count($metaLines) * 11.0 + 16.0);
        $p->rect(0, 0, $pw, $headerH, self::C_DARK_BLUE);

        // Bedrijfsnaam (links)
        if ($companyName) {
            $p->text($ml, 22, $cw * 0.55, $companyName, 15, true, self::C_WHITE);
        }
        // Meta-regels (links)
        $metaY = 22.0 + 18.0 + 5.0;
        foreach ($metaLines as $ml2) {
            $p->text($ml, $metaY, $cw * 0.55, $ml2, 7.5, false, self::C_WHITE);
            $metaY += 11.0;
        }

        // Document-type (rechts, groot)
        $rightX = $ml + $cw * 0.52;
        $rightW = $cw * 0.48;
        $p->text($rightX, 20, $rightW, $typeLabel, 26, true, self::C_WHITE, 'R');
        $p->text($rightX, 52, $rightW, $docNumber, 10, false, self::C_WHITE, 'R');

        // ── 2. ACCENTBALK ────────────────────────────────────────────
        $p->rect(0, $headerH, $pw, 4, self::C_ACCENT_BLUE);

        // ── 3. INFO-SECTIE ───────────────────────────────────────────
        $y = $headerH + 4 + 20;

        $leftW    = $cw * 0.5 - 10;
        $infoRX   = $ml + $cw * 0.5 + 10;
        $infoRW   = $cw * 0.5 - 10;

        // Links: ontvanger
        $lbl = strtoupper($isInvoice ? 'Factuur voor' : 'Offerte voor');
        $p->text($ml, $y, $leftW, $lbl, 7, true, self::C_GRAY);
        $infoY = $y + 13;
        if ($cCompany) {
            $p->text($ml, $infoY, $leftW, $cCompany, 9.5, true, self::C_DARK_TEXT);
            $infoY += 15;
        }
        if ($cName) {
            $p->text($ml, $infoY, $leftW, $cName, 9.5, false, self::C_DARK_TEXT);
            $infoY += 15;
        }
        if ($cAddress) {
            $p->text($ml, $infoY, $leftW, $cAddress, 9.5, false, self::C_DARK_TEXT);
            $infoY += 15;
        }
        if ($cPc || $cCity) {
            $p->text($ml, $infoY, $leftW, trim("{$cPc} {$cCity}"), 9.5, false, self::C_DARK_TEXT);
            $infoY += 15;
        }
        if ($cEmail) {
            $p->text($ml, $infoY, $leftW, $cEmail, 9.5, false, self::C_DARK_TEXT);
            $infoY += 15;
        }

        // Rechts: meta-tabel
        $metaRows = [
            [$isInvoice ? 'Factuurnummer:' : 'Offertenummer:', $docNumber],
            [$isInvoice ? 'Factuurdatum:'  : 'Datum:', date('d-m-Y', strtotime($docDate))],
        ];
        if ($docExpiry) {
            $metaRows[] = [$expiryLabel . ':', date('d-m-Y', strtotime($docExpiry))];
        }
        $metaRY   = $y;
        $lblColW  = 85;
        $valColW  = $infoRW - $lblColW;
        foreach ($metaRows as [$lbl2, $val]) {
            $p->text($infoRX,            $metaRY, $lblColW, $lbl2, 9, false, self::C_GRAY);
            $p->text($infoRX + $lblColW, $metaRY, $valColW, $val,  9, true,  self::C_DARK_TEXT);
            $metaRY += 16;
        }

        $y = max($infoY, $metaRY) + 14;

        // ── 4. INTRO-BOX ─────────────────────────────────────────────
        if ($docIntro !== '') {
            $introLines = $p->wrap($docIntro, $cw - 16, 9, false);
            $introH     = 12 + count($introLines) * 12.6 + 12;
            $p->rect($ml, $y, $cw, $introH, self::C_LIGHT_BG, 'FD', self::C_BORDER);
            $p->multiLine($ml + 8, $y + 12, $cw - 16, $docIntro, 9, false,
                [0.290, 0.333, 0.408], 12.6);
            $y += $introH + 10;
        }

        // ── 5. REGELITEMS-TABEL ──────────────────────────────────────

        // Kolombreedtes
        $colDesc  = $cw - 65 - 90 - 90; // ~294 pt
        $colAantal = 65.0;
        $colPrijs  = 90.0;
        $colTotaal = 90.0;

        // Optionele titel
        if ($docTitle !== '') {
            $p->text($ml, $y, $cw, $docTitle, 10.5, true, self::C_DARK_BLUE);
            $y += 18;
        }

        // Tabelkop
        $thH  = 22.0;
        $p->rect($ml, $y, $cw, $thH, self::C_DARK_BLUE);
        $thY  = $y + ($thH - 8) * 0.5;
        $p->text($ml + 6,                               $thY, $colDesc - 6,  'Omschrijving', 8, true, self::C_WHITE);
        $p->text($ml + $colDesc,                         $thY, $colAantal,    'Aantal',       8, true, self::C_WHITE, 'C');
        $p->text($ml + $colDesc + $colAantal,            $thY, $colPrijs - 4, 'Stuksprijs',   8, true, self::C_WHITE, 'R');
        $p->text($ml + $colDesc + $colAantal + $colPrijs,$thY, $colTotaal - 4,'Totaal',       8, true, self::C_WHITE, 'R');
        $y += $thH;

        // Rijen
        foreach ($items as $idx => $item) {
            $desc      = $item['description'] ?? '';
            $descLines = $p->wrap($desc, $colDesc - 12, 9, false);
            $rowH      = max(20.0, count($descLines) * 13.0 + 8.0);

            // Alternatieve achtergrond
            if ($idx % 2 === 1) {
                $p->rect($ml, $y, $cw, $rowH, self::C_LIGHT_BG);
            }
            // Onderlijn
            $p->line($ml, $y + $rowH, $ml + $cw, $y + $rowH, self::C_BORDER, 0.3);

            $rowTY = $y + ($rowH - 9) * 0.5;

            // Beschrijving (eventueel meerdere regels)
            $p->multiLine($ml + 6, $y + 5, $colDesc - 12, $desc, 9, false, self::C_DARK_TEXT, 13.0);

            // Getal-kolommen (verticaal gecentreerd)
            $qty    = rtrim(rtrim(number_format((float)($item['quantity']   ?? 0), 2, ',', '.'), '0'), ',');
            $price  = chr(128) . ' ' . number_format((float)($item['unit_price'] ?? 0), 2, ',', '.');
            $ltotal = chr(128) . ' ' . number_format((float)($item['line_total'] ?? 0), 2, ',', '.');

            $p->text($ml + $colDesc,                          $rowTY, $colAantal,     $qty,    9, false, self::C_DARK_TEXT, 'C');
            $p->text($ml + $colDesc + $colAantal,             $rowTY, $colPrijs - 4,  $price,  9, false, self::C_DARK_TEXT, 'R');
            $p->text($ml + $colDesc + $colAantal + $colPrijs, $rowTY, $colTotaal - 4, $ltotal, 9, false, self::C_DARK_TEXT, 'R');

            $y += $rowH;
        }
        $y += 10;

        // ── 6. TOTALEN ───────────────────────────────────────────────
        $totW     = 220.0;
        $totX     = $ml + $cw - $totW;
        $totLblW  = 130.0;
        $totValW  = $totW - $totLblW;
        $eur      = chr(128); // € in Windows-1252

        $self = self::C_DARK_TEXT;
        $gray = self::C_GRAY;

        $p->text($totX,           $y, $totLblW, 'Subtotaal',    9.5, false, $gray);
        $p->text($totX + $totLblW, $y, $totValW, "{$eur} " . number_format($subtotal, 2, ',', '.'), 9.5, false, $self, 'R');
        $y += 15;

        if ($discount > 0) {
            $p->text($totX,            $y, $totLblW, 'Korting',    9.5, false, $gray);
            $p->text($totX + $totLblW, $y, $totValW, "-  {$eur} " . number_format($discount, 2, ',', '.'), 9.5, false, self::C_RED, 'R');
            $y += 15;
        }

        $taxRateDisplay = (is_numeric($taxRate) && floor((float)$taxRate) == (float)$taxRate)
            ? (int)$taxRate
            : $taxRate;
        $p->text($totX,            $y, $totLblW, "BTW ({$taxRateDisplay}%)", 9.5, false, $gray);
        $p->text($totX + $totLblW, $y, $totValW, "{$eur} " . number_format($taxAmount, 2, ',', '.'), 9.5, false, $self, 'R');
        $y += 10;

        // Scheidingslijn
        $p->line($totX, $y, $totX + $totW, $y, self::C_DARK_BLUE, 1.5);
        $y += 10;

        // Totaalregel (groot + vet)
        $p->text($totX,            $y, $totLblW, 'Totaal', 12, true, self::C_DARK_BLUE);
        $p->text($totX + $totLblW, $y, $totValW, "{$eur} " . number_format($total, 2, ',', '.'), 12, true, self::C_DARK_BLUE, 'R');
        $y += 22;

        // ── 7. DOCUMENTVOET ──────────────────────────────────────────
        $y += 8;
        $p->line($ml, $y, $ml + $cw, $y, self::C_BORDER, 0.5);
        $y += 12;

        if ($docFooter !== '') {
            $y = $p->multiLine($ml, $y, $cw, $docFooter, 8, false, $gray, 12);
            $y += 4;
        }

        if ($isInvoice && $companyIban) {
            $dueStr = $docExpiry ? ', v\xf3\xf3r ' . date('d-m-Y', strtotime($docExpiry)) : '';
            $payText = "Betaling: Maak {$eur} " . number_format($total, 2, ',', '.')
                . " over op {$companyIban} o.v.v. {$docNumber}{$dueStr}.";
            $p->multiLine($ml, $y, $cw, $payText, 8, false, $gray, 12);
        }

        // ── 8. ONDERSTE BALK ────────────────────────────────────────
        $p->rect(0, CpPdfWriter::PH - 6, $pw, 6, self::C_DARK_BLUE);

        return $p->output();
    }

    /**
     * Stuur PDF direct als download naar de browser.
     *
     * @param string $type     'invoice' of 'quote'
     * @param array  $doc      Factuur/offerte record
     * @param array  $items    Regelitems
     * @param array  $customer Klant record
     * @param string $filename Bestandsnaam (bijv. 'Factuur-F2025-001.pdf')
     */
    public static function downloadDocument(
        string $type, array $doc, array $items, array $customer, string $filename
    ): never {
        $pdf = self::documentToPdf($type, $doc, $items, $customer);
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . addslashes($filename) . '"');
        header('Content-Length: ' . strlen($pdf));
        echo $pdf;
        exit;
    }

    // ── HTML-sjabloon (voor browserweergave) ────────────────────────

    /**
     * Genereer een print-vriendelijk HTML-document voor een factuur of offerte.
     * Wordt gebruikt voor de browser-preview/printknop.
     *
     * @param string $type     'invoice' of 'quote'
     * @param array  $doc      Factuur/offerte record (incl. totalen)
     * @param array  $items    Regelitems
     * @param array  $customer Klant record
     */
    public static function renderDocument(string $type, array $doc, array $items, array $customer): string
    {
        $isInvoice = ($type === 'invoice');

        $companyName    = htmlspecialchars(Settings::get('cp_company_name')    ?: '');
        $companyAddress = htmlspecialchars(Settings::get('cp_company_address') ?: '');
        $companyPc      = htmlspecialchars(Settings::get('cp_company_postcode') ?: '');
        $companyCity    = htmlspecialchars(Settings::get('cp_company_city')    ?: '');
        $companyKvk     = htmlspecialchars(Settings::get('cp_company_kvk')     ?: '');
        $companyBtw     = htmlspecialchars(Settings::get('cp_company_btw')     ?: '');
        $companyIban    = htmlspecialchars(Settings::get('cp_company_iban')    ?: '');

        $docNumber   = htmlspecialchars($isInvoice ? ($doc['invoice_number'] ?? '') : ($doc['quote_number'] ?? ''));
        $docDate     = $isInvoice ? ($doc['invoice_date'] ?? date('Y-m-d')) : ($doc['created_at'] ?? date('Y-m-d'));
        $docExpiry   = $isInvoice ? ($doc['due_date'] ?? null) : ($doc['valid_until'] ?? null);
        $expiryLabel = $isInvoice ? 'Vervaldatum' : 'Geldig tot';
        $typeLabel   = $isInvoice ? 'FACTUUR' : 'OFFERTE';

        $subtotal  = (float)($doc['subtotal']   ?? 0);
        $discount  = (float)($doc['discount']   ?? 0);
        $taxAmount = (float)($doc['tax_amount'] ?? 0);
        $total     = (float)($doc['total']      ?? 0);
        $taxRate   = $doc['tax_rate'] ?? 21;

        $cName    = htmlspecialchars($customer['contact_name'] ?? '');
        $cCompany = htmlspecialchars($customer['company_name'] ?? '');
        $cAddress = htmlspecialchars($customer['address']      ?? '');
        $cPc      = htmlspecialchars($customer['postcode']     ?? '');
        $cCity    = htmlspecialchars($customer['city']         ?? '');
        $cEmail   = htmlspecialchars($customer['email']        ?? '');

        $docTitle  = htmlspecialchars($doc['title']  ?? '');
        $docIntro  = nl2br(htmlspecialchars($doc['intro']  ?? ''));
        $docFooter = nl2br(htmlspecialchars($doc['footer'] ?? ''));

        ob_start();
        ?>
<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: DejaVu Sans, Arial, sans-serif; font-size:10pt; color:#1a202c; background:#fff; }

/* ── Header ── */
.hd { background:#1e3a5f; color:#fff; padding:24px 28px 20px; }
.hd-table { width:100%; border-collapse:collapse; }
.co-name { font-size:15pt; font-weight:bold; margin-bottom:4px; }
.co-meta { font-size:7.5pt; line-height:1.65; opacity:.85; }
.doc-type { font-size:26pt; font-weight:bold; letter-spacing:2px; line-height:1; text-align:right; }
.doc-num  { font-size:10pt; opacity:.85; text-align:right; margin-top:4px; }

/* ── Accent bar ── */
.accent { height:4px; background:linear-gradient(90deg,#3b82f6,#60a5fa); }

/* ── Info-rij ── */
.info { padding:20px 28px; display:table; width:100%; }
.ic   { display:table-cell; vertical-align:top; width:50%; }
.ic-r { padding-left:24px; }
.lbl  { font-size:7pt; text-transform:uppercase; letter-spacing:.8px; color:#718096; font-weight:bold; margin-bottom:5px; }
.val  { font-size:9.5pt; line-height:1.7; }
.meta-tbl { width:100%; border-collapse:collapse; }
.meta-tbl td { padding:3px 4px; font-size:9pt; }
.meta-tbl td:last-child { text-align:right; font-weight:bold; }
.meta-key { color:#718096; font-weight:normal !important; }

/* ── Intro ── */
.intro-box { padding:12px 28px; background:#f8fafc; font-size:9pt; color:#4a5568; line-height:1.6; border-bottom:1px solid #e2e8f0; }

/* ── Items ── */
.items { padding:20px 28px 8px; }
.doc-title { font-size:10.5pt; font-weight:bold; color:#1e3a5f; margin-bottom:10px; }
.it { width:100%; border-collapse:collapse; }
.it th { background:#1e3a5f; color:#fff; padding:8px 10px; font-size:8pt; font-weight:bold; text-align:left; }
.it th.r { text-align:right; }
.it th.c { text-align:center; }
.it td { padding:7px 10px; font-size:9pt; border-bottom:1px solid #e2e8f0; }
.it td.r { text-align:right; }
.it td.c { text-align:center; }
.it tr.even td { background:#f8fafc; }

/* ── Totalen ── */
.totals { padding:4px 28px 22px; }
.tot-tbl { width:240px; margin-left:auto; border-collapse:collapse; }
.tot-tbl td { padding:4px 6px; font-size:9.5pt; }
.tot-tbl td.r { text-align:right; }
.tot-key { color:#718096; }
.tot-row td { font-size:12pt; font-weight:bold; color:#1e3a5f; padding-top:9px !important; border-top:2px solid #1e3a5f; }

/* ── Footer ── */
.doc-footer { margin:0 28px; padding:14px 0; border-top:1px solid #e2e8f0; font-size:8pt; color:#718096; line-height:1.7; }
.bot-bar { background:#1e3a5f; height:6px; }
</style>
</head>
<body>

<!-- HEADER -->
<div class="hd">
  <table class="hd-table">
    <tr>
      <td style="vertical-align:top;">
        <?php if ($companyName): ?><div class="co-name"><?= $companyName ?></div><?php endif; ?>
        <div class="co-meta">
          <?php if ($companyAddress): ?><?= $companyAddress ?><br><?php endif; ?>
          <?php if ($companyPc || $companyCity): ?><?= $companyPc ?> <?= $companyCity ?><br><?php endif; ?>
          <?php if ($companyKvk): ?>KVK: <?= $companyKvk ?><?php if ($companyBtw): ?> &nbsp;|&nbsp; <?php endif; ?><?php endif; ?>
          <?php if ($companyBtw): ?>BTW: <?= $companyBtw ?><?php endif; ?>
        </div>
      </td>
      <td style="vertical-align:top;">
        <div class="doc-type"><?= $typeLabel ?></div>
        <div class="doc-num"><?= $docNumber ?></div>
      </td>
    </tr>
  </table>
</div>
<div class="accent"></div>

<!-- INFO-RIJ -->
<div class="info">
  <div class="ic">
    <div class="lbl"><?= $isInvoice ? 'Factuur voor' : 'Offerte voor' ?></div>
    <div class="val">
      <?php if ($cCompany): ?><strong><?= $cCompany ?></strong><br><?php endif; ?>
      <?= $cName ?>
      <?php if ($cAddress): ?><br><?= $cAddress ?><?php endif; ?>
      <?php if ($cPc || $cCity): ?><br><?= $cPc ?> <?= $cCity ?><?php endif; ?>
      <?php if ($cEmail): ?><br><?= $cEmail ?><?php endif; ?>
    </div>
  </div>
  <div class="ic ic-r">
    <table class="meta-tbl">
      <tr>
        <td class="meta-key"><?= $isInvoice ? 'Factuurnummer' : 'Offertenummer' ?>:</td>
        <td><?= $docNumber ?></td>
      </tr>
      <tr>
        <td class="meta-key"><?= $isInvoice ? 'Factuurdatum' : 'Datum' ?>:</td>
        <td><?= date('d-m-Y', strtotime($docDate)) ?></td>
      </tr>
      <?php if ($docExpiry): ?>
      <tr>
        <td class="meta-key"><?= $expiryLabel ?>:</td>
        <td><?= date('d-m-Y', strtotime($docExpiry)) ?></td>
      </tr>
      <?php endif; ?>
    </table>
  </div>
</div>

<?php if ($docIntro): ?>
<div class="intro-box"><?= $docIntro ?></div>
<?php endif; ?>

<!-- REGELS -->
<div class="items">
  <?php if ($docTitle): ?><div class="doc-title"><?= $docTitle ?></div><?php endif; ?>
  <table class="it">
    <thead>
      <tr>
        <th>Omschrijving</th>
        <th class="c" style="width:65px;">Aantal</th>
        <th class="r" style="width:95px;">Stuksprijs</th>
        <th class="r" style="width:95px;">Totaal</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $idx => $item): ?>
      <tr class="<?= $idx % 2 === 1 ? 'even' : '' ?>">
        <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
        <td class="c"><?= rtrim(rtrim(number_format((float)($item['quantity'] ?? 0), 2, ',', '.'), '0'), ',') ?></td>
        <td class="r">&euro;&nbsp;<?= number_format((float)($item['unit_price'] ?? 0), 2, ',', '.') ?></td>
        <td class="r">&euro;&nbsp;<?= number_format((float)($item['line_total'] ?? 0), 2, ',', '.') ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<!-- TOTALEN -->
<div class="totals">
  <table class="tot-tbl">
    <tr>
      <td class="tot-key">Subtotaal</td>
      <td class="r">&euro;&nbsp;<?= number_format($subtotal, 2, ',', '.') ?></td>
    </tr>
    <?php if ($discount > 0): ?>
    <tr>
      <td class="tot-key">Korting</td>
      <td class="r" style="color:#e53e3e;">-&nbsp;&euro;&nbsp;<?= number_format($discount, 2, ',', '.') ?></td>
    </tr>
    <?php endif; ?>
    <tr>
      <td class="tot-key">BTW (<?= is_numeric($taxRate) && floor($taxRate) == $taxRate ? (int)$taxRate : $taxRate ?>%)</td>
      <td class="r">&euro;&nbsp;<?= number_format($taxAmount, 2, ',', '.') ?></td>
    </tr>
    <tr class="tot-row">
      <td>Totaal</td>
      <td class="r">&euro;&nbsp;<?= number_format($total, 2, ',', '.') ?></td>
    </tr>
  </table>
</div>

<!-- DOCUMENTVOET -->
<div class="doc-footer">
  <?php if ($docFooter): ?><p style="margin-bottom:6px;"><?= $docFooter ?></p><?php endif; ?>
  <?php if ($isInvoice && $companyIban): ?>
  <p>
    Betaling: Maak <strong>&euro;&nbsp;<?= number_format($total, 2, ',', '.') ?></strong> over op
    <strong><?= $companyIban ?></strong> o.v.v. <strong><?= $docNumber ?></strong><?php if ($docExpiry): ?>, v&oacute;&oacute;r <?= date('d-m-Y', strtotime($docExpiry)) ?><?php endif; ?>.
  </p>
  <?php endif; ?>
</div>
<div class="bot-bar"></div>

</body>
</html>
        <?php
        return ob_get_clean();
    }

    /**
     * Open een print-vriendelijke HTML-pagina in de browser (met printdialoog).
     * Gebruik downloadDocument() voor een echte PDF-download.
     */
    public static function download(string $html, string $filename): never
    {
        header('Content-Type: text/html; charset=utf-8');
        echo $html;
        echo '<script>window.onload=function(){window.print();}</script>';
        exit;
    }
}

<?php
/**
 * Customer Portal – lib/CpPdfWriter.php
 * Minimale pure-PHP PDF-generator. Geen externe dependencies.
 * Gebruikt ingebouwde Helvetica-fonts (standaard in elke PDF-viewer).
 * Coördinatensysteem: linker-bovenhoek = (0,0), eenheid: punten (pt).
 */
class CpPdfWriter
{
    const PW = 595.28;   // A4 breedte (pt)
    const PH = 841.89;   // A4 hoogte  (pt)

    private array  $pages = [];
    private string $buf   = '';

    // ── Paginabeheer ─────────────────────────────────────────────────

    public function addPage(): void
    {
        if ($this->buf !== '') {
            $this->pages[] = $this->buf;
        }
        $this->buf = '';
    }

    // ── Tekenprimatieven ─────────────────────────────────────────────

    /**
     * Gevulde/omrande rechthoek. x,y = linker-bovenhoek.
     * @param string $style  'F'=fill, 'D'=stroke, 'FD'=fill+stroke
     */
    public function rect(
        float  $x,      float  $y,
        float  $w,      float  $h,
        array  $fill   = [1, 1, 1],
        string $style  = 'F',
        array  $stroke = [0, 0, 0],
        float  $lw     = 0.5
    ): void {
        $py = self::PH - $y - $h;
        $op = match ($style) { 'D' => 'S', 'FD' => 'B', default => 'f' };
        $fc = sprintf('%.3f %.3f %.3f rg', ...$fill);
        $sc = sprintf('%.3f %.3f %.3f RG', ...$stroke);
        $this->buf .= "q {$fc} {$sc} {$lw} w "
            . sprintf("%.2f %.2f %.2f %.2f re %s Q\n", $x, $py, $w, $h, $op);
    }

    /** Lijn van (x1,y1) naar (x2,y2). */
    public function line(
        float $x1,     float $y1,
        float $x2,     float $y2,
        array $stroke = [0, 0, 0],
        float $lw     = 0.5
    ): void {
        $py1 = self::PH - $y1;
        $py2 = self::PH - $y2;
        $sc  = sprintf('%.3f %.3f %.3f RG', ...$stroke);
        $this->buf .= sprintf(
            "q {$sc} %.2f w %.2f %.2f m %.2f %.2f l S Q\n",
            $lw, $x1, $py1, $x2, $py2
        );
    }

    /**
     * Schrijf één regel tekst.
     * x,y = linker-bovenhoek van de tekstcel; w = breedte voor uitlijning.
     * @param string $align  'L', 'R', 'C'
     */
    public function text(
        float  $x,     float  $y,    float $w,  string $text,
        float  $size  = 10,
        bool   $bold  = false,
        array  $color = [0, 0, 0],
        string $align = 'L'
    ): void {
        if ($text === '') return;
        $fn  = $bold ? 'F2' : 'F1';
        $tw  = $this->textWidth($text, $size, $bold);
        $px  = match ($align) {
            'R'     => $x + $w - $tw,
            'C'     => $x + ($w - $tw) / 2.0,
            default => $x,
        };
        // Baseline in PDF-coördinaten (Y = 0 is onderkant pagina)
        $py  = self::PH - ($y + $size * 0.78);
        $tc  = sprintf('%.3f %.3f %.3f rg', ...$color);
        $enc = $this->encode($text);
        $this->buf .= sprintf(
            "q %s BT /%s %.2f Tf %.2f %.2f Td (%s) Tj ET Q\n",
            $tc, $fn, $size, $px, $py, $enc
        );
    }

    /**
     * Meerregelige tekst met automatische woordafbreking.
     * Geeft de Y-positie terug ná de laatste regel.
     */
    public function multiLine(
        float  $x,    float  $y,     float $w,   string $text,
        float  $size  = 10,
        bool   $bold  = false,
        array  $color = [0, 0, 0],
        float  $lineH = 0.0,
        string $align = 'L'
    ): float {
        if ($lineH <= 0) $lineH = $size * 1.4;
        foreach ($this->wrap($text, $w, $size, $bold) as $line) {
            $this->text($x, $y, $w, $line, $size, $bold, $color, $align);
            $y += $lineH;
        }
        return $y;
    }

    /**
     * Splits tekst in regels die binnen maxW passen.
     * @return string[]
     */
    public function wrap(string $text, float $maxW, float $size, bool $bold): array
    {
        $paragraphs = preg_split('/\r?\n/', $text);
        $lines = [];
        foreach ($paragraphs as $para) {
            if ($para === '') { $lines[] = ''; continue; }
            $words = explode(' ', $para);
            $cur   = '';
            foreach ($words as $word) {
                $test = $cur === '' ? $word : "{$cur} {$word}";
                if ($this->textWidth($test, $size, $bold) <= $maxW) {
                    $cur = $test;
                } else {
                    if ($cur !== '') $lines[] = $cur;
                    $cur = $word;
                }
            }
            if ($cur !== '') $lines[] = $cur;
        }
        return $lines ?: [''];
    }

    /**
     * Bereken tekstbreedte in punten voor Helvetica (AFM-metriek).
     */
    public function textWidth(string $text, float $size, bool $bold = false): float
    {
        // Helvetica AFM breedtes (1/1000 van de fontgrootte per teken)
        static $hw = [
            32=>278, 33=>278, 34=>355, 35=>556, 36=>556, 37=>889, 38=>667, 39=>191,
            40=>333, 41=>333, 42=>389, 43=>584, 44=>278, 45=>333, 46=>278, 47=>278,
            48=>556, 49=>556, 50=>556, 51=>556, 52=>556, 53=>556, 54=>556, 55=>556,
            56=>556, 57=>556, 58=>278, 59=>278, 60=>584, 61=>584, 62=>584, 63=>556,
            64=>1015,65=>667, 66=>667, 67=>722, 68=>722, 69=>667, 70=>611, 71=>778,
            72=>722, 73=>278, 74=>500, 75=>667, 76=>556, 77=>833, 78=>722, 79=>778,
            80=>667, 81=>778, 82=>722, 83=>667, 84=>611, 85=>722, 86=>667, 87=>944,
            88=>667, 89=>667, 90=>611, 91=>278, 92=>278, 93=>278, 94=>469, 95=>556,
            96=>333, 97=>556, 98=>556, 99=>500,100=>556,101=>556,102=>278,103=>556,
           104=>556,105=>222,106=>222,107=>500,108=>222,109=>833,110=>556,111=>556,
           112=>556,113=>556,114=>333,115=>500,116=>278,117=>556,118=>500,119=>722,
           120=>500,121=>500,122=>500,123=>334,124=>260,125=>334,126=>584,
            // Windows-1252 uitbreidingen
           128=>556,  // €
           196=>667,214=>778,220=>722,  // Ä Ö Ü
           228=>556,246=>556,252=>556,  // ä ö ü
           233=>556,232=>556,234=>556,235=>556,  // é è ê ë
           237=>278,236=>278,238=>278,239=>278,  // í ì î ï
           243=>556,242=>556,244=>556,245=>556,  // ó ò ô õ
           225=>556,224=>556,226=>556,227=>556,  // á à â ã
           231=>500,                              // ç
        ];
        $factor = $bold ? 1.05 : 1.0;
        $latin  = @mb_convert_encoding($text, 'Windows-1252', 'UTF-8') ?: $text;
        $total  = 0.0;
        for ($i = 0, $n = strlen($latin); $i < $n; $i++) {
            $total += ($hw[ord($latin[$i])] ?? 556) * $factor;
        }
        return $total * $size / 1000.0;
    }

    // ── Uitvoer ──────────────────────────────────────────────────────

    /** Geef de PDF-bytes als string. */
    public function output(): string
    {
        if ($this->buf !== '') {
            $this->pages[] = $this->buf;
            $this->buf     = '';
        }

        $pdf  = "%PDF-1.4\n";
        $offs = [];
        $pos  = strlen($pdf);

        $add = function (int $n, string $body) use (&$pdf, &$offs, &$pos): void {
            $offs[$n] = $pos;
            $s        = "{$n} 0 obj\n{$body}\nendobj\n";
            $pdf     .= $s;
            $pos     += strlen($s);
        };

        $np          = count($this->pages);
        $firstPage   = 5;
        $firstStream = $firstPage + $np;
        $kids        = implode(' ', array_map(
            fn ($i) => ($firstPage + $i) . ' 0 R',
            range(0, $np - 1)
        ));

        $add(1, '<< /Type /Catalog /Pages 2 0 R >>');
        $add(2, "<< /Type /Pages /Kids [{$kids}] /Count {$np} >>");
        $add(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
        $add(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');

        foreach ($this->pages as $i => $stream) {
            $streamObj = $firstStream + $i;
            $add(
                $firstPage + $i,
                '<< /Type /Page /Parent 2 0 R '
                . '/MediaBox [0 0 595.28 841.89] '
                . "/Contents {$streamObj} 0 R "
                . '/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>'
            );
            $len = strlen($stream);
            $add($streamObj, "<< /Length {$len} >>\nstream\n{$stream}\nendstream");
        }

        $maxObj  = max(array_keys($offs));
        $xrefPos = $pos;
        $pdf    .= "xref\n0 " . ($maxObj + 1) . "\n";
        $pdf    .= "0000000000 65535 f \n";
        for ($i = 1; $i <= $maxObj; $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offs[$i] ?? 0);
        }
        $pdf .= "trailer\n<< /Size " . ($maxObj + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n{$xrefPos}\n%%EOF\n";

        return $pdf;
    }

    // ── Private helpers ──────────────────────────────────────────────

    /** Zet UTF-8-tekst om naar Windows-1252 en escape PDF-speciale tekens. */
    private function encode(string $text): string
    {
        $s = @mb_convert_encoding($text, 'Windows-1252', 'UTF-8');
        if (!$s) {
            $s = preg_replace('/[^\x20-\x7E]/', '?', $text) ?? $text;
        }
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }
}

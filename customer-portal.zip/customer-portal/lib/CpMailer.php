<?php
/**
 * Customer Portal – lib/CpMailer.php
 * E-mailverzending voor facturen en offertes, met PDF als bijlage.
 */
class CpMailer
{
    /**
     * Stuur een factuur of offerte als e-mail naar de klant.
     * Als mPDF beschikbaar is, wordt de PDF als bijlage toegevoegd.
     *
     * @param string $type     'invoice' of 'quote'
     * @param array  $doc      Factuur/offerte record
     * @param array  $items    Regelitems
     * @param array  $customer Klant record
     */
    public static function sendDocument(string $type, array $doc, array $items, array $customer, ?string $approvalToken = null): bool
    {
        $to = trim($customer['email'] ?? '');
        if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        $isInvoice = ($type === 'invoice');
        $docNumber = $isInvoice ? ($doc['invoice_number'] ?? '') : ($doc['quote_number'] ?? '');

        $fromName  = Settings::get('cp_mail_from_name')  ?: Settings::get('cp_company_name') ?: 'Klantenpaneel';
        $fromEmail = Settings::get('cp_mail_from_email') ?: ('noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));

        $subjectTpl = $isInvoice
            ? (Settings::get('cp_mail_invoice_subject') ?: 'Uw factuur {nummer}')
            : (Settings::get('cp_mail_quote_subject')   ?: 'Uw offerte {nummer}');
        $subject = str_replace('{nummer}', $docNumber, $subjectTpl);

        // Genereer PDF (ingebouwde generator, altijd beschikbaar)
        $pdfData  = null;
        $filename = $docNumber . '.pdf';
        try {
            $pdfData = CpPdf::documentToPdf($type, $doc, $items, $customer);
        } catch (\Throwable $e) {
            // Zonder PDF-bijlage doorgaan als generatie onverwacht mislukt
        }

        $bodyHtml = self::buildEmailBody($type, $doc, $customer, $pdfData !== null, $approvalToken);
        $boundary = 'CP_' . bin2hex(random_bytes(12));
        $from     = '=?UTF-8?B?' . base64_encode($fromName) . '?= <' . $fromEmail . '>';

        if ($pdfData !== null) {
            // Multipart/mixed met PDF-bijlage
            $headers  = "From: {$from}\r\n";
            $headers .= "Reply-To: {$fromEmail}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"\r\n";
            $headers .= "X-Mailer: ROICT CMS\r\n";

            $body  = "--{$boundary}\r\n";
            $body .= "Content-Type: text/html; charset=UTF-8\r\n";
            $body .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";
            $body .= quoted_printable_encode($bodyHtml) . "\r\n\r\n";
            $body .= "--{$boundary}\r\n";
            $body .= "Content-Type: application/pdf; name=\"{$filename}\"\r\n";
            $body .= "Content-Transfer-Encoding: base64\r\n";
            $body .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n\r\n";
            $body .= chunk_split(base64_encode($pdfData)) . "\r\n";
            $body .= "--{$boundary}--";
        } else {
            // Alleen HTML-mail
            $headers  = "From: {$from}\r\n";
            $headers .= "Reply-To: {$fromEmail}\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "Content-Transfer-Encoding: quoted-printable\r\n";
            $headers .= "X-Mailer: ROICT CMS\r\n";
            $body = quoted_printable_encode($bodyHtml);
        }

        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        return mail($to, $encodedSubject, $body, $headers);
    }

    private static function buildEmailBody(string $type, array $doc, array $customer, bool $hasPdf, ?string $approvalToken = null): string
    {
        $isInvoice = ($type === 'invoice');
        $docNumber = htmlspecialchars($isInvoice ? ($doc['invoice_number'] ?? '') : ($doc['quote_number'] ?? ''));
        $name      = htmlspecialchars($customer['contact_name'] ?? 'Klant');
        $company   = htmlspecialchars(Settings::get('cp_company_name') ?: '');
        $total     = '&euro;&nbsp;' . number_format((float)($doc['total'] ?? 0), 2, ',', '.');

        $intro = $isInvoice
            ? "Hierbij ontvangt u uw factuur <strong>{$docNumber}</strong>."
            : "Hierbij ontvangt u uw offerte <strong>{$docNumber}</strong>.";

        if ($isInvoice && !empty($doc['due_date'])) {
            $due   = date('d-m-Y', strtotime($doc['due_date']));
            $iban  = htmlspecialchars(Settings::get('cp_company_iban') ?: '');
            $ibanStr = $iban ? " op rekening <strong>{$iban}</strong>" : '';
            $extra = "<p style=\"margin:0 0 14px;color:#4a5568;font-size:14px;line-height:1.6;\">Graag het bedrag van <strong>{$total}</strong> vóór <strong>{$due}</strong> voldoen{$ibanStr} o.v.v. <strong>{$docNumber}</strong>.</p>";
        } elseif (!$isInvoice && !empty($doc['valid_until'])) {
            $until = date('d-m-Y', strtotime($doc['valid_until']));
            $extra = "<p style=\"margin:0 0 14px;color:#4a5568;font-size:14px;line-height:1.6;\">Deze offerte is geldig tot <strong>{$until}</strong>.</p>";
        } else {
            $extra = '';
        }

        $attachNote = $hasPdf
            ? '<p style="margin:0 0 14px;color:#4a5568;font-size:14px;line-height:1.6;">De ' . ($isInvoice ? 'factuur' : 'offerte') . ' is als PDF-bijlage toegevoegd aan dit bericht.</p>'
            : '';

        // Goedkeur/afwijs-knoppen voor offertes
        $approvalButtons = '';
        if (!$isInvoice && $approvalToken) {
            $baseUrl     = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '';
            $acceptUrl   = htmlspecialchars($baseUrl . '/offerte-actie/' . $approvalToken . '/accepteer');
            $rejectUrl   = htmlspecialchars($baseUrl . '/offerte-actie/' . $approvalToken . '/afwijzen');
            $approvalButtons = <<<HTML
          <!-- Goedkeur / afwijs knoppen -->
          <table width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0 8px;">
            <tr>
              <td align="center" style="padding:0 8px 0 0;">
                <a href="{$acceptUrl}"
                   style="display:inline-block;padding:14px 28px;background:#22c55e;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:8px;letter-spacing:.3px;">
                  ✓ &nbsp;Offerte accepteren
                </a>
              </td>
              <td align="center" style="padding:0 0 0 8px;">
                <a href="{$rejectUrl}"
                   style="display:inline-block;padding:14px 28px;background:#ef4444;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:8px;letter-spacing:.3px;">
                  ✕ &nbsp;Offerte afwijzen
                </a>
              </td>
            </tr>
          </table>
          <p style="margin:8px 0 0;color:#a0aec0;font-size:11px;text-align:center;">
            Door op een knop te klikken geeft u uw reactie direct door aan ons systeem.
          </p>
HTML;
        }

        return <<<HTML
<!DOCTYPE html>
<html lang="nl">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f4f8;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f4f8;padding:32px 0;">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;overflow:hidden;box-shadow:0 4px 16px rgba(0,0,0,.10);">

      <!-- Header -->
      <tr>
        <td style="background:#1e3a5f;padding:26px 32px 22px;">
          <p style="margin:0;color:#ffffff;font-size:20px;font-weight:bold;letter-spacing:.3px;">{$company}</p>
          <p style="margin:5px 0 0;color:rgba(255,255,255,.70);font-size:12px;">{$docNumber}</p>
        </td>
      </tr>

      <!-- Accent streep -->
      <tr><td style="height:4px;background:linear-gradient(90deg,#3b82f6,#60a5fa);font-size:0;">&nbsp;</td></tr>

      <!-- Body -->
      <tr>
        <td style="padding:32px 32px 24px;">
          <p style="margin:0 0 18px;color:#1a202c;font-size:15px;">Geachte {$name},</p>
          <p style="margin:0 0 18px;color:#4a5568;font-size:14px;line-height:1.6;">{$intro}</p>

          <!-- Totaal-blok -->
          <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0;margin-bottom:20px;">
            <tr>
              <td style="padding:18px 22px;">
                <p style="margin:0;font-size:11px;color:#718096;text-transform:uppercase;letter-spacing:.8px;">Totaalbedrag</p>
                <p style="margin:6px 0 0;font-size:26px;font-weight:bold;color:#1e3a5f;">{$total}</p>
                <p style="margin:4px 0 0;font-size:12px;color:#718096;">{$docNumber}</p>
              </td>
            </tr>
          </table>

          {$extra}
          {$attachNote}
          {$approvalButtons}

          <p style="margin:24px 0 0;color:#4a5568;font-size:14px;line-height:1.6;">
            Met vriendelijke groet,<br>
            <strong style="color:#1a202c;">{$company}</strong>
          </p>
        </td>
      </tr>

      <!-- Footer -->
      <tr>
        <td style="background:#f8fafc;padding:16px 32px;border-top:1px solid #e2e8f0;">
          <p style="margin:0;font-size:11px;color:#a0aec0;text-align:center;">
            Dit is een automatisch gegenereerd bericht. Heeft u vragen? Neem dan contact met ons op.
          </p>
        </td>
      </tr>

    </table>
  </td></tr>
</table>
</body>
</html>
HTML;
    }
}

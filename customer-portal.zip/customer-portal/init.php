<?php
/**
 * Customer Portal – init.php
 * Wordt geladen bij elke pagina-aanvraag als de module actief is.
 */

require_once __DIR__ . '/lib/CpPdfWriter.php';
require_once __DIR__ . '/lib/CpPdf.php';
require_once __DIR__ . '/lib/CpMailer.php';

// ----------------------------------------------------------------
// Automatische database-migratie: voeg approval_token toe als
// de kolom nog niet bestaat (voor installaties vóór deze versie).
// ----------------------------------------------------------------
(function () {
    $db = Database::getInstance();
    $p  = DB_PREFIX;
    try {
        $db->query("ALTER TABLE `{$p}cp_quotes` ADD COLUMN `approval_token` VARCHAR(64) DEFAULT NULL");
    } catch (\Throwable $e) {
        // Kolom bestaat al — negeer
    }
    try {
        $db->query("ALTER TABLE `{$p}cp_quotes` ADD UNIQUE KEY `uq_approval_token` (`approval_token`)");
    } catch (\Throwable $e) {
        // Index bestaat al — negeer
    }
})();

// ----------------------------------------------------------------
// Hulpfuncties
// ----------------------------------------------------------------

/**
 * Controleer of de ingelogde frontend-gebruiker een klantprofiel heeft.
 * Geeft de klant-rij terug of false.
 */
function cp_get_current_customer(): array|false
{
    if (!class_exists('FrontendLoginModule') || !FrontendLoginModule::isLoggedIn()) {
        return false;
    }
    $user = FrontendLoginModule::currentUser();
    if (!$user) {
        return false;
    }
    $db = Database::getInstance();
    return $db->fetch(
        "SELECT * FROM `" . DB_PREFIX . "cp_customers` WHERE `fl_user_id` = ? OR `email` = ? LIMIT 1",
        [$user['id'], $user['email']]
    );
}

/**
 * Genereer een volgend offertenummer.
 */
function cp_next_quote_number(): string
{
    $prefix  = Settings::get('cp_quote_prefix') ?: 'O';
    $counter = (int)(Settings::get('cp_quote_counter') ?: 1);
    Settings::set('cp_quote_counter', $counter + 1);
    return $prefix . str_pad($counter, 4, '0', STR_PAD_LEFT);
}

/**
 * Genereer een volgend factuurnummer.
 */
function cp_next_invoice_number(): string
{
    $prefix  = Settings::get('cp_invoice_prefix') ?: 'F';
    $counter = (int)(Settings::get('cp_invoice_counter') ?: 1);
    Settings::set('cp_invoice_counter', $counter + 1);
    return $prefix . str_pad($counter, 4, '0', STR_PAD_LEFT);
}

/**
 * Bereken offerteregel-totalen en sla op.
 */
function cp_recalculate_quote(int $quoteId): void
{
    $db  = Database::getInstance();
    $p   = DB_PREFIX;

    $items    = $db->fetchAll("SELECT * FROM `{$p}cp_quote_items` WHERE `quote_id` = ?", [$quoteId]);
    $subtotal = 0;
    foreach ($items as $item) {
        $subtotal += $item['line_total'];
    }

    $quote    = $db->fetch("SELECT * FROM `{$p}cp_quotes` WHERE `id` = ?", [$quoteId]);
    $discount = (float)($quote['discount'] ?? 0);
    $taxRate  = (float)($quote['tax_rate']  ?? 21);
    $base     = $subtotal - $discount;
    $tax      = round($base * $taxRate / 100, 2);
    $total    = $base + $tax;

    $db->update("{$p}cp_quotes", [
        'subtotal'   => $subtotal,
        'tax_amount' => $tax,
        'total'      => $total,
    ], "id = {$quoteId}");
}

/**
 * Bereken factuurregel-totalen en sla op.
 */
function cp_recalculate_invoice(int $invoiceId): void
{
    $db  = Database::getInstance();
    $p   = DB_PREFIX;

    $items    = $db->fetchAll("SELECT * FROM `{$p}cp_invoice_items` WHERE `invoice_id` = ?", [$invoiceId]);
    $subtotal = 0;
    foreach ($items as $item) {
        $subtotal += $item['line_total'];
    }

    $invoice  = $db->fetch("SELECT * FROM `{$p}cp_invoices` WHERE `id` = ?", [$invoiceId]);
    $discount = (float)($invoice['discount'] ?? 0);
    $taxRate  = (float)($invoice['tax_rate']  ?? 21);
    $base     = $subtotal - $discount;
    $tax      = round($base * $taxRate / 100, 2);
    $total    = $base + $tax;

    $db->update("{$p}cp_invoices", [
        'subtotal'   => $subtotal,
        'tax_amount' => $tax,
        'total'      => $total,
    ], "id = {$invoiceId}");
}

// ----------------------------------------------------------------
// Admin navigatie
// ----------------------------------------------------------------
add_action('admin_sidebar_nav', function (string $activePage) {
    $pages = [
        'klantenpaneel'          => ['label' => 'Klanten',      'icon' => 'people',            'url' => BASE_URL . '/admin/modules/customer-portal/?page=customers'],
        'klantenpaneel-quotes'   => ['label' => 'Offertes',     'icon' => 'file-earmark-text', 'url' => BASE_URL . '/admin/modules/customer-portal/?page=quotes'],
        'klantenpaneel-invoices' => ['label' => 'Facturen',     'icon' => 'receipt',           'url' => BASE_URL . '/admin/modules/customer-portal/?page=invoices'],
        'klantenpaneel-settings' => ['label' => 'Instellingen', 'icon' => 'gear',              'url' => BASE_URL . '/admin/modules/customer-portal/?page=settings'],
    ];

    echo '<div class="nav-section">Klantenpaneel</div>';
    foreach ($pages as $pageKey => $info) {
        $active = ($activePage === $pageKey) ? 'active' : '';
        printf(
            '<a href="%s" class="nav-link %s"><i class="bi bi-%s"></i> %s</a>',
            e($info['url']),
            $active,
            e($info['icon']),
            e($info['label'])
        );
    }
});

// ----------------------------------------------------------------
// Frontend CSS/JS toevoegen
// ----------------------------------------------------------------
add_action('theme_head', function () {
    if (Settings::get('cp_portal_enabled') !== '1') {
        return;
    }
    echo '<link rel="stylesheet" href="' . BASE_URL . '/modules/customer-portal/assets/css/customer-portal.css">' . "\n";
});

add_action('theme_footer', function () {
    if (Settings::get('cp_portal_enabled') !== '1') {
        return;
    }
    echo '<script src="' . BASE_URL . '/modules/customer-portal/assets/js/customer-portal.js"></script>' . "\n";
});

// ----------------------------------------------------------------
// Frontend routing – offerte goed-/afkeuring via e-maillink (geen login vereist)
// ----------------------------------------------------------------
add_action('frontend_route', function (string $uri) {
    $path = trim($uri, '/');

    // Patroon: offerte-actie/{64-hex-token}/{accepteer|afwijzen}
    if (!preg_match('#^offerte-actie/([a-f0-9]{64})/(accepteer|afwijzen)$#', $path, $m)) {
        return;
    }

    $token  = $m[1];
    $actie  = $m[2]; // 'accepteer' of 'afwijzen'
    $db     = Database::getInstance();
    $p      = DB_PREFIX;

    $quote = $db->fetch(
        "SELECT q.*, c.contact_name, c.company_name
         FROM `{$p}cp_quotes` q
         JOIN `{$p}cp_customers` c ON c.id = q.customer_id
         WHERE q.approval_token = ?",
        [$token]
    );

    $activeTheme = Settings::get('active_theme') ?: 'default';
    define('CP_PORTAL_HANDLED', true);

    if (!$quote) {
        http_response_code(410);
        require THEMES_PATH . '/' . $activeTheme . '/header.php';
        echo '<div style="max-width:560px;margin:60px auto;text-align:center;font-family:Arial,sans-serif;">'
           . '<h1 style="color:#e53e3e;">Ongeldige link</h1>'
           . '<p style="color:#4a5568;">Deze link is niet geldig of al gebruikt.</p>'
           . '</div>';
        require THEMES_PATH . '/' . $activeTheme . '/footer.php';
        exit;
    }

    // Alleen reageren als offerte nog in behandeling is
    $verwerkbaar = in_array($quote['status'], ['concept', 'sent'], true);

    if ($verwerkbaar) {
        $nieuweStatus = ($actie === 'accepteer') ? 'accepted' : 'rejected';
        $db->update("{$p}cp_quotes", [
            'status'         => $nieuweStatus,
            'approval_token' => null, // token onbruikbaar maken na gebruik
        ], "id = " . (int)$quote['id']);
    }

    $klantnaam  = htmlspecialchars($quote['company_name'] ?: $quote['contact_name']);
    $nummer     = htmlspecialchars($quote['quote_number']);
    $company    = htmlspecialchars(Settings::get('cp_company_name') ?: '');

    require THEMES_PATH . '/' . $activeTheme . '/header.php';

    if (!$verwerkbaar) {
        // Offerte is al verwerkt
        echo <<<HTML
<div style="max-width:560px;margin:60px auto;text-align:center;font-family:Arial,sans-serif;padding:0 16px;">
  <div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:10px;padding:32px;">
    <p style="font-size:48px;margin:0 0 12px;">⚠️</p>
    <h1 style="color:#92400e;font-size:1.4rem;margin:0 0 10px;">Al verwerkt</h1>
    <p style="color:#78350f;margin:0;">Offerte <strong>{$nummer}</strong> is al eerder verwerkt en kan niet meer worden gewijzigd.</p>
  </div>
</div>
HTML;
    } elseif ($actie === 'accepteer') {
        echo <<<HTML
<div style="max-width:560px;margin:60px auto;text-align:center;font-family:Arial,sans-serif;padding:0 16px;">
  <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:40px 32px;">
    <p style="font-size:56px;margin:0 0 16px;">✅</p>
    <h1 style="color:#166534;font-size:1.5rem;margin:0 0 12px;">Offerte geaccepteerd!</h1>
    <p style="color:#15803d;font-size:1rem;line-height:1.6;margin:0 0 8px;">
      Bedankt, <strong>{$klantnaam}</strong>!<br>
      U heeft offerte <strong>{$nummer}</strong> geaccepteerd.
    </p>
    <p style="color:#4a5568;font-size:.9rem;margin:16px 0 0;">
      Wij nemen zo snel mogelijk contact met u op.<br>
      <strong>{$company}</strong>
    </p>
  </div>
</div>
HTML;
    } else {
        echo <<<HTML
<div style="max-width:560px;margin:60px auto;text-align:center;font-family:Arial,sans-serif;padding:0 16px;">
  <div style="background:#fff5f5;border:1px solid #fca5a5;border-radius:10px;padding:40px 32px;">
    <p style="font-size:56px;margin:0 0 16px;">❌</p>
    <h1 style="color:#991b1b;font-size:1.5rem;margin:0 0 12px;">Offerte afgewezen</h1>
    <p style="color:#b91c1c;font-size:1rem;line-height:1.6;margin:0 0 8px;">
      Bedankt voor uw reactie, <strong>{$klantnaam}</strong>.<br>
      U heeft offerte <strong>{$nummer}</strong> afgewezen.
    </p>
    <p style="color:#4a5568;font-size:.9rem;margin:16px 0 0;">
      Heeft u vragen of wilt u een aangepaste offerte? Neem gerust contact op.<br>
      <strong>{$company}</strong>
    </p>
  </div>
</div>
HTML;
    }

    require THEMES_PATH . '/' . $activeTheme . '/footer.php';
    exit;
});

// ----------------------------------------------------------------
// Frontend routing – onderschep klantenpaneel-URL's
// ----------------------------------------------------------------
add_action('frontend_route', function (string $uri) {
    if (Settings::get('cp_portal_enabled') !== '1') {
        return;
    }

    $slug = trim(Settings::get('cp_portal_slug') ?: 'klanten-portaal', '/');
    $uri  = trim($uri, '/');

    // Komt de aanvraag overeen met het portaal-pad?
    if ($uri !== $slug && strpos($uri, $slug . '/') !== 0) {
        return;
    }

    // Frontend login verplicht
    if (!class_exists('FrontendLoginModule') || !FrontendLoginModule::isLoggedIn()) {
        $loginSlug = ltrim(Settings::get('cp_login_slug') ?: Settings::get('fl_login_page_slug') ?: 'inloggen', '/');
        redirect(BASE_URL . '/' . $loginSlug . '?redirect=' . urlencode('/' . $uri));
    }

    // Bepaal sub-pagina
    $sub = '';
    if (strlen($uri) > strlen($slug)) {
        $sub = ltrim(substr($uri, strlen($slug)), '/');
    }

    // Klantprofiel ophalen (maak automatisch aan als nog niet bestaat)
    $customer = cp_get_current_customer();
    if (!$customer) {
        // Automatisch klantprofiel aanmaken op basis van login-data
        $user = FrontendLoginModule::currentUser();
        $db   = Database::getInstance();
        $db->insert(DB_PREFIX . 'cp_customers', [
            'fl_user_id'   => $user['id'],
            'contact_name' => $user['username'] ?? $user['email'],
            'email'        => $user['email'],
            'status'       => 'active',
        ]);
        $customer = cp_get_current_customer();
    }

    // Route naar sub-pagina
    $map = [
        ''          => __DIR__ . '/frontend/portal.php',
        'offertes'  => __DIR__ . '/frontend/quotes.php',
        'facturen'  => __DIR__ . '/frontend/invoices.php',
        'profiel'   => __DIR__ . '/frontend/profile.php',
    ];

    // Enkelvoudige offerte/factuur detail-pagina's
    if (preg_match('#^offertes/(\d+)$#', $sub, $m)) {
        $_GET['cp_quote_id'] = (int)$m[1];
        $file = __DIR__ . '/frontend/quote-detail.php';
    } elseif (preg_match('#^facturen/(\d+)$#', $sub, $m)) {
        $_GET['cp_invoice_id'] = (int)$m[1];
        $file = __DIR__ . '/frontend/invoice-detail.php';
    } else {
        $file = $map[$sub] ?? null;
    }

    if ($file && file_exists($file)) {
        // Markeer als afgehandeld zodat de hoofd-router stopt
        define('CP_PORTAL_HANDLED', true);
        require $file;
        exit;
    }

    // 404 als geen match
    http_response_code(404);
    define('CP_PORTAL_HANDLED', true);
    require THEMES_PATH . '/' . (Settings::get('active_theme') ?: 'default') . '/404.php';
    exit;
});

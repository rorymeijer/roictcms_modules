<?php
/**
 * WYSIWYG Editor Module — Uninstall Script
 * Wordt uitgevoerd bij verwijdering van de module.
 */

// Geen database-tabellen of instellingen om op te ruimen.
return ['success' => true];

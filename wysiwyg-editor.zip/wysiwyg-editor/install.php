<?php
/**
 * WYSIWYG Editor Module — Install Script
 * Wordt éénmalig uitgevoerd bij installatie van de module.
 */

// Geen database-tabellen nodig — de module werkt volledig via hooks.
return ['success' => true, 'message' => 'WYSIWYG Editor geïnstalleerd.'];

<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();
require_once dirname(__DIR__) . '/functions.php';

$db        = Database::getInstance();
$pageTitle = 'Analytics';
$activePage = 'analytics';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { flash('error', 'Ongeldige aanvraag.'); redirect(BASE_URL . '/admin/analytics/'); }
    $action = $_POST['action'] ?? '';
    if ($action === 'save_settings') {
        Settings::setMultiple([
            'analytics_exclude_admins' => isset($_POST['exclude_admins']) ? '1' : '0',
            'analytics_exclude_bots'   => isset($_POST['exclude_bots'])   ? '1' : '0',
            'analytics_retention_days' => max(1, (int)($_POST['retention_days'] ?? 90)),
        ]);
        flash('success', 'Instellingen opgeslagen.');
    }
    if ($action === 'purge') {
        $days = (int) Settings::get('analytics_retention_days', '90');
        $db->query(
            "DELETE FROM `" . DB_PREFIX . "analytics_hits` WHERE created_at < ?",
            [date('Y-m-d H:i:s', strtotime("-{$days} days"))]
        );
        flash('success', 'Oude statistieken opgeschoond.');
    }
    redirect(BASE_URL . '/admin/analytics/');
}

$days  = (int)($_GET['days'] ?? 30);
$days  = in_array($days, [7, 30, 90], true) ? $days : 30;
$stats = analytics_get_stats($days);

require_once ADMIN_PATH . '/includes/header.php';
?>
<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <h1 class="mb-0"><i class="bi bi-graph-up"></i> <?= e($pageTitle) ?></h1>
    <div class="d-flex gap-2">
        <a href="?days=7"  class="btn btn-sm <?= $days===7  ? 'btn-primary':'btn-outline-secondary' ?>">7 dagen</a>
        <a href="?days=30" class="btn btn-sm <?= $days===30 ? 'btn-primary':'btn-outline-secondary' ?>">30 dagen</a>
        <a href="?days=90" class="btn btn-sm <?= $days===90 ? 'btn-primary':'btn-outline-secondary' ?>">90 dagen</a>
    </div>
</div>
<?= renderFlash() ?>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <div class="fs-2 fw-bold text-primary"><?= number_format((int)($stats['total']['cnt'] ?? 0)) ?></div>
                <div class="text-muted small">Paginaweergaven</div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <div class="fs-2 fw-bold text-success"><?= number_format((int)($stats['unique']['cnt'] ?? 0)) ?></div>
                <div class="text-muted small">Unieke bezoekers</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>Populaire pagina's</strong></div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <thead><tr><th>URL</th><th class="text-end">Views</th></tr></thead>
                    <tbody>
                        <?php foreach ($stats['topPages'] as $p): ?>
                        <tr><td class="text-truncate" style="max-width:250px;"><?= e($p['url']) ?></td><td class="text-end"><?= number_format((int)$p['views']) ?></td></tr>
                        <?php endforeach; ?>
                        <?php if (empty($stats['topPages'])): ?><tr><td colspan="2" class="text-center text-muted py-3">Geen data.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card h-100">
            <div class="card-header"><strong>Verwijzende domeinen</strong></div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <thead><tr><th>Verwijzer</th><th class="text-end">Bezoeken</th></tr></thead>
                    <tbody>
                        <?php foreach ($stats['topReferrers'] as $r): ?>
                        <tr><td class="text-truncate" style="max-width:250px;"><?= e($r['referrer']) ?></td><td class="text-end"><?= number_format((int)$r['cnt']) ?></td></tr>
                        <?php endforeach; ?>
                        <?php if (empty($stats['topReferrers'])): ?><tr><td colspan="2" class="text-center text-muted py-3">Geen data.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-header"><strong>Dagelijkse weergaven (<?= $days ?> dagen)</strong></div>
    <div class="card-body p-0">
        <table class="table table-sm mb-0">
            <thead><tr><th>Dag</th><th>Weergaven</th><th style="width:50%"></th></tr></thead>
            <tbody>
                <?php $maxV = max(1, max(array_column($stats['dailyViews'] ?: [['views'=>0]], 'views')));
                foreach ($stats['dailyViews'] as $d):
                    $pct = round(($d['views'] / $maxV) * 100); ?>
                <tr>
                    <td><?= e($d['day']) ?></td>
                    <td><?= number_format((int)$d['views']) ?></td>
                    <td><div class="progress" style="height:10px;"><div class="progress-bar" style="width:<?= $pct ?>%"></div></div></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($stats['dailyViews'])): ?><tr><td colspan="3" class="text-center text-muted py-3">Geen data.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header"><strong>Instellingen</strong></div>
    <div class="card-body">
        <form method="POST" class="row g-3 align-items-end">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_settings">
            <div class="col-auto form-check form-switch mt-2 ms-2">
                <input class="form-check-input" type="checkbox" name="exclude_admins" id="exAdm"
                       <?= Settings::get('analytics_exclude_admins','1')==='1'?'checked':'' ?>>
                <label class="form-check-label" for="exAdm">Admins uitsluiten</label>
            </div>
            <div class="col-auto form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" name="exclude_bots" id="exBot"
                       <?= Settings::get('analytics_exclude_bots','1')==='1'?'checked':'' ?>>
                <label class="form-check-label" for="exBot">Bots uitsluiten</label>
            </div>
            <div class="col-auto">
                <label class="form-label">Bewaarperiode (dagen)</label>
                <input type="number" name="retention_days" class="form-control" min="1"
                       value="<?= (int) Settings::get('analytics_retention_days','90') ?>" style="width:100px;">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Opslaan</button>
            </div>
        </form>
        <form method="POST" class="mt-3">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="purge">
            <button type="submit" class="btn btn-outline-danger btn-sm"
                    onclick="return confirm('Oude statistieken opschonen?')">
                <i class="bi bi-trash"></i> Verouderde data opschonen
            </button>
        </form>
    </div>
</div>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

<?php
function analytics_get_stats(int $days = 30): array {
    $db    = Database::getInstance();
    $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));

    $total   = $db->fetch("SELECT COUNT(*) AS cnt FROM `" . DB_PREFIX . "analytics_hits` WHERE created_at >= ?", [$since]);
    $unique  = $db->fetch("SELECT COUNT(DISTINCT ip_hash) AS cnt FROM `" . DB_PREFIX . "analytics_hits` WHERE created_at >= ?", [$since]);
    $topPages = $db->fetchAll(
        "SELECT url, COUNT(*) AS views FROM `" . DB_PREFIX . "analytics_hits`
         WHERE created_at >= ? GROUP BY url ORDER BY views DESC LIMIT 10",
        [$since]
    );
    $topReferrers = $db->fetchAll(
        "SELECT referrer, COUNT(*) AS cnt FROM `" . DB_PREFIX . "analytics_hits`
         WHERE created_at >= ? AND referrer IS NOT NULL AND referrer != ''
         GROUP BY referrer ORDER BY cnt DESC LIMIT 10",
        [$since]
    );
    $dailyViews = $db->fetchAll(
        "SELECT DATE(created_at) AS day, COUNT(*) AS views FROM `" . DB_PREFIX . "analytics_hits`
         WHERE created_at >= ? GROUP BY DATE(created_at) ORDER BY day ASC",
        [$since]
    );

    return compact('total', 'unique', 'topPages', 'topReferrers', 'dailyViews');
}

<?php
$db = Database::getInstance();
$db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "analytics_hits`");
foreach (['analytics_exclude_admins','analytics_exclude_bots','analytics_retention_days'] as $k) {
    $db->delete(DB_PREFIX . 'settings', '`key` = ?', [$k]);
}

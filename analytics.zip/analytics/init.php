<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'analytics' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/analytics/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-graph-up me-2"></i>Analytics</a>';
});

add_action('frontend_init', function () {
    if (Settings::get('analytics_exclude_admins', '1') === '1' && Auth::isLoggedIn()) return;
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (Settings::get('analytics_exclude_bots', '1') === '1') {
        $botPattern = '/bot|crawl|slurp|spider|mediapartners|google|bingpreview|facebook|twitter|lighthouse/i';
        if (preg_match($botPattern, $ua)) return;
    }
    $db = Database::getInstance();
    $db->insert(DB_PREFIX . 'analytics_hits', [
        'url'        => substr($_SERVER['REQUEST_URI'] ?? '/', 0, 2000),
        'referrer'   => isset($_SERVER['HTTP_REFERER']) ? substr($_SERVER['HTTP_REFERER'], 0, 2000) : null,
        'ip_hash'    => hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . date('Y-m-d')),
        'user_agent' => substr($ua, 0, 500),
    ]);
});

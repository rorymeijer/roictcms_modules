<?php
$db = Database::getInstance();
$db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "analytics_hits` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `url` VARCHAR(2000) NOT NULL,
    `referrer` VARCHAR(2000) DEFAULT NULL,
    `ip_hash` VARCHAR(64) NOT NULL,
    `user_agent` VARCHAR(500) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

Settings::setMultiple([
    'analytics_exclude_admins' => '1',
    'analytics_exclude_bots'   => '1',
    'analytics_retention_days' => '90',
]);

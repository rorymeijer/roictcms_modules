<?php
/**
 * Zoekmodule - Install
 */

defined('BASE_PATH') || exit('No direct access');

$db = Database::getInstance();

// Standaard instellingen opslaan
$settings = [
    'search_max_results' => '10',
    'search_pages'       => '1',
    'search_news'        => '1',
];

foreach ($settings as $key => $value) {
    Settings::set($key, $value);
}

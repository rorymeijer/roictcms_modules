<?php
$db = Database::getInstance();
foreach (['maintenance_enabled','maintenance_title','maintenance_message','maintenance_email','maintenance_allowed_ips'] as $k) {
    $db->delete(DB_PREFIX . 'settings', 'setting_key = ?', [$k]);
}

<?php
require_once dirname(__DIR__, 3) . '/admin/includes/init.php';
Auth::requireAdmin();

$pageTitle = 'Onderhoudsmodus';
$activePage = 'maintenance-mode';
$enabled = Settings::get('maintenance_enabled', '0') === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) { flash('error', 'Ongeldige aanvraag.'); redirect(BASE_URL . '/admin/maintenance-mode/'); }
    Settings::setMultiple([
        'maintenance_enabled'     => isset($_POST['enabled']) ? '1' : '0',
        'maintenance_title'       => trim($_POST['title']   ?? ''),
        'maintenance_message'     => trim($_POST['message'] ?? ''),
        'maintenance_email'       => trim($_POST['email']   ?? ''),
        'maintenance_allowed_ips' => trim($_POST['allowed_ips'] ?? ''),
    ]);
    flash('success', 'Instellingen opgeslagen.');
    redirect(BASE_URL . '/admin/maintenance-mode/');
}

require_once ADMIN_PATH . '/includes/header.php';
?>
<div class="page-header d-flex align-items-center gap-3">
    <h1 class="mb-0"><i class="bi bi-tools"></i> <?= e($pageTitle) ?></h1>
    <?php if ($enabled): ?>
        <span class="badge bg-warning text-dark fs-6">ACTIEF</span>
    <?php else: ?>
        <span class="badge bg-success fs-6">Website online</span>
    <?php endif; ?>
</div>
<?= renderFlash() ?>

<?php if ($enabled): ?>
<div class="alert alert-warning">
    <i class="bi bi-exclamation-triangle-fill"></i>
    <strong>Let op:</strong> de website is momenteel in onderhoudsmodus. Bezoekers zien een onderhoudspagina.
</div>
<?php endif; ?>

<div class="card" style="max-width:700px;">
    <div class="card-body">
        <form method="POST">
            <?= csrf_field() ?>
            <div class="mb-4 form-check form-switch">
                <input class="form-check-input" type="checkbox" name="enabled" id="enabled"
                       style="width:3em;height:1.5em;" <?= $enabled ? 'checked' : '' ?>>
                <label class="form-check-label fs-5 ms-2" for="enabled"><strong>Onderhoudsmodus inschakelen</strong></label>
            </div>
            <div class="mb-3">
                <label class="form-label">Paginatitel</label>
                <input type="text" name="title" class="form-control"
                       value="<?= e(Settings::get('maintenance_title', 'Even geduld…')) ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Boodschap aan bezoekers</label>
                <textarea name="message" class="form-control" rows="3"><?= e(Settings::get('maintenance_message', '')) ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Contacte-mail (optioneel)</label>
                <input type="email" name="email" class="form-control"
                       value="<?= e(Settings::get('maintenance_email', '')) ?>">
            </div>
            <div class="mb-4">
                <label class="form-label">Toegestane IP-adressen</label>
                <textarea name="allowed_ips" class="form-control" rows="3"
                          placeholder="1.2.3.4&#10;5.6.7.8"><?= e(Settings::get('maintenance_allowed_ips', '')) ?></textarea>
                <div class="form-text">Één IP-adres per regel. Deze bezoekers zien de website normaal.</div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-save"></i> Opslaan</button>
        </form>
    </div>
</div>

<?php require_once ADMIN_PATH . '/includes/footer.php'; ?>

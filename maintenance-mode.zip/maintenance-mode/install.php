<?php
Settings::setMultiple([
    'maintenance_enabled'     => '0',
    'maintenance_title'       => 'Even geduld…',
    'maintenance_message'     => 'We zijn bezig met onderhoudswerkzaamheden. We zijn snel weer terug!',
    'maintenance_email'       => '',
    'maintenance_allowed_ips' => '',
]);

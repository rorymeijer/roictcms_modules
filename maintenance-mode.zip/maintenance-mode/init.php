<?php
// ── Sidebar-navigatie ─────────────────────────────────────────────────────────
add_action('admin_sidebar_nav', function ($activePage) {
    $isActive = ($activePage ?? '') === 'maintenance-mode' ? ' active' : '';
    echo '<a href="' . e(BASE_URL) . '/admin/modules/maintenance-mode/" class="nav-link' . $isActive . '">'
       . '<i class="bi bi-tools me-2"></i>Onderhoudsmodus</a>';
});

add_action('frontend_init', function () {
    if (Settings::get('maintenance_enabled', '0') !== '1') return;
    if (Auth::isLoggedIn()) return;

    $allowed = array_filter(array_map('trim', explode("\n", Settings::get('maintenance_allowed_ips', ''))));
    $ip      = $_SERVER['REMOTE_ADDR'] ?? '';
    if ($allowed && in_array($ip, $allowed, true)) return;

    $title   = e(Settings::get('maintenance_title', 'Even geduld…'));
    $message = e(Settings::get('maintenance_message', ''));
    $email   = Settings::get('maintenance_email', '');

    http_response_code(503);
    header('Retry-After: 3600');
    echo '<!DOCTYPE html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>' . $title . '</title>
<style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f8f9fa;}
.box{text-align:center;max-width:500px;padding:2rem;}h1{font-size:2rem;margin-bottom:1rem;}p{color:#555;}</style></head>
<body><div class="box"><h1>' . $title . '</h1><p>' . $message . '</p>'
    . ($email ? '<p><a href="mailto:' . e($email) . '">' . e($email) . '</a></p>' : '')
    . '</div></body></html>';
    exit;
});

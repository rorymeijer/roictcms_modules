<?php
// Geen frontend-init nodig voor backup-manager.
